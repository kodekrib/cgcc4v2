<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.spouseDetail.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.spouse-details.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group" id="title">
                <label><?php echo e(trans('cruds.spouseDetail.fields.title')); ?></label>
                <select class="form-control <?php echo e($errors->has('title') ? 'is-invalid' : ''); ?>" name="title">
                  <option value disabled <?php echo e(old('title', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                  <option value="Mr" <?php echo e(old('title', '') === 'Mr' ? 'selected' : ''); ?>>Mr</option>
                  <option value="Mrs" <?php echo e(old('title', '') === 'Mrs' ? 'selected' : ''); ?>>Mrs</option>
                </select>
                <?php if($errors->has('title')): ?>
                  <div class="invalid-feedback">
                    <?php echo e($errors->first('title')); ?>

                  </div>
                <?php endif; ?>
              </div>
            
            <div class="form-group">
                <label class="required" for="last_name"><?php echo e(trans('cruds.spouseDetail.fields.last_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('last_name') ? 'is-invalid' : ''); ?>" type="text" name="last_name" id="last_name" value="<?php echo e(Auth::user()->name); ?>" readonly required>
                <?php if($errors->has('last_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('last_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.spouseDetail.fields.last_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="first_name"><?php echo e(trans('cruds.spouseDetail.fields.first_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('first_name') ? 'is-invalid' : ''); ?>" type="text" name="first_name" id="first_name" value="<?php echo e(old('first_name', '')); ?>">
                <?php if($errors->has('first_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('first_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.spouseDetail.fields.first_name_helper')); ?></span>
            </div>
            <div class="form-group" id="maiden_name" style="display: none;">
                <label for="maiden_name"><?php echo e(trans('cruds.spouseDetail.fields.maiden_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('maiden_name') ? 'is-invalid' : ''); ?>" type="text" name="maiden_name" id="maiden_name" value="<?php echo e(old('maiden_name', '')); ?>">
                <?php if($errors->has('maiden_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('maiden_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.spouseDetail.fields.maiden_name_helper')); ?></span>
            </div>
            
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.spouseDetail.fields.relationship')); ?></label>
                <select class="form-control <?php echo e($errors->has('relationship') ? 'is-invalid' : ''); ?>" name="relationship" id="relationship" required>
                    <option value disabled <?php echo e(old('relationship', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\SpouseDetail::RELATIONSHIP_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('relationship', 'Wife') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('relationship')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('relationship')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.spouseDetail.fields.relationship_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="date_of_birth"><?php echo e(trans('cruds.spouseDetail.fields.date_of_birth')); ?></label>
                <input class="form-control date <?php echo e($errors->has('date_of_birth') ? 'is-invalid' : ''); ?>" type="text" name="date_of_birth" id="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>" required>
                <?php if($errors->has('date_of_birth')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('date_of_birth')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.spouseDetail.fields.date_of_birth_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="wedding_anniv"><?php echo e(trans('cruds.spouseDetail.fields.wedding_anniv')); ?></label>
                <input class="form-control date <?php echo e($errors->has('wedding_anniv') ? 'is-invalid' : ''); ?>" type="text" name="wedding_anniv" id="wedding_anniv" value="<?php echo e(old('wedding_anniv')); ?>" required>
                <?php if($errors->has('wedding_anniv')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('wedding_anniv')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.spouseDetail.fields.wedding_anniv_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>

<script>
    const titleSelect = document.querySelector('select[name="title"]');
    const maidenName = document.querySelector('#maiden_name');
  
    titleSelect.addEventListener('change', function() {
      if (this.value === 'Mrs') {
        maidenName.style.display = 'block';
      } else {
        maidenName.style.display = 'none';
      }
    });
  </script> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/spouseDetails/create.blade.php ENDPATH**/ ?>