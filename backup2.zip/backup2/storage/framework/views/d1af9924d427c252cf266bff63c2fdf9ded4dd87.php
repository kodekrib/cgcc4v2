<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.firstTimer.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.first-timers.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="service"><?php echo e(trans('cruds.firstTimer.fields.service')); ?></label>
                <input class="form-control date <?php echo e($errors->has('service') ? 'is-invalid' : ''); ?>" type="text" name="service" id="service" value="<?php echo e(old('service')); ?>">
                <?php if($errors->has('service')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('service')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.service_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="surname"><?php echo e(trans('cruds.firstTimer.fields.surname')); ?></label>
                <input class="form-control <?php echo e($errors->has('surname') ? 'is-invalid' : ''); ?>" type="text" name="surname" id="surname" value="<?php echo e(old('surname', '')); ?>">
                <?php if($errors->has('surname')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('surname')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.surname_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="first_name"><?php echo e(trans('cruds.firstTimer.fields.first_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('first_name') ? 'is-invalid' : ''); ?>" type="text" name="first_name" id="first_name" value="<?php echo e(old('first_name', '')); ?>">
                <?php if($errors->has('first_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('first_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.first_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="middle_name"><?php echo e(trans('cruds.firstTimer.fields.middle_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('middle_name') ? 'is-invalid' : ''); ?>" type="text" name="middle_name" id="middle_name" value="<?php echo e(old('middle_name', '')); ?>">
                <?php if($errors->has('middle_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('middle_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.middle_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="date_of_birth"><?php echo e(trans('cruds.firstTimer.fields.date_of_birth')); ?></label>
                <input class="form-control date <?php echo e($errors->has('date_of_birth') ? 'is-invalid' : ''); ?>" type="text" name="date_of_birth" id="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>">
                <?php if($errors->has('date_of_birth')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('date_of_birth')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.date_of_birth_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="marital_status_id"><?php echo e(trans('cruds.firstTimer.fields.marital_status')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('marital_status') ? 'is-invalid' : ''); ?>" name="marital_status_id" id="marital_status_id">
                    <?php $__currentLoopData = $marital_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('marital_status_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('marital_status')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('marital_status')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.marital_status_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="occupation"><?php echo e(trans('cruds.firstTimer.fields.occupation')); ?></label>
                <input class="form-control <?php echo e($errors->has('occupation') ? 'is-invalid' : ''); ?>" type="text" name="occupation" id="occupation" value="<?php echo e(old('occupation', '')); ?>">
                <?php if($errors->has('occupation')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('occupation')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.occupation_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.firstTimer.fields.gender')); ?></label>
                <select class="form-control <?php echo e($errors->has('gender') ? 'is-invalid' : ''); ?>" name="gender" id="gender">
                    <option value disabled <?php echo e(old('gender', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\FirstTimer::GENDER_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('gender', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('gender')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('gender')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.gender_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="phone_number"><?php echo e(trans('cruds.firstTimer.fields.phone_number')); ?></label>
                <input class="form-control <?php echo e($errors->has('phone_number') ? 'is-invalid' : ''); ?>" type="text" name="phone_number" id="phone_number" value="<?php echo e(old('phone_number', '')); ?>">
                <?php if($errors->has('phone_number')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('phone_number')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.phone_number_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="email"><?php echo e(trans('cruds.firstTimer.fields.email')); ?></label>
                <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="email" name="email" id="email" value="<?php echo e(old('email')); ?>">
                <?php if($errors->has('email')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('email')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.email_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="residential_address"><?php echo e(trans('cruds.firstTimer.fields.residential_address')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('residential_address') ? 'is-invalid' : ''); ?>" name="residential_address" id="residential_address"><?php echo e(old('residential_address')); ?></textarea>
                <?php if($errors->has('residential_address')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('residential_address')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.residential_address_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="nearest_bus_stop"><?php echo e(trans('cruds.firstTimer.fields.nearest_bus_stop')); ?></label>
                <input class="form-control <?php echo e($errors->has('nearest_bus_stop') ? 'is-invalid' : ''); ?>" type="text" name="nearest_bus_stop" id="nearest_bus_stop" value="<?php echo e(old('nearest_bus_stop', '')); ?>">
                <?php if($errors->has('nearest_bus_stop')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nearest_bus_stop')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.nearest_bus_stop_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.firstTimer.fields.country')); ?></label>
                <select class="form-control <?php echo e($errors->has('country') ? 'is-invalid' : ''); ?>" name="country" id="country">
                    <option value disabled <?php echo e(old('country', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\FirstTimer::COUNTRY_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('country', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('country')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('country')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.country_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.firstTimer.fields.state')); ?></label>
                <select class="form-control <?php echo e($errors->has('state') ? 'is-invalid' : ''); ?>" name="state" id="state">
                    <option value disabled <?php echo e(old('state', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\FirstTimer::STATE_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('state', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('state')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('state')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.state_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.firstTimer.fields.city')); ?></label>
                <select class="form-control <?php echo e($errors->has('city') ? 'is-invalid' : ''); ?>" name="city" id="city">
                    <option value disabled <?php echo e(old('city', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\FirstTimer::CITY_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('city', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('city')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('city')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.city_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.firstTimer.fields.join_cgcc')); ?></label>
                <select class="form-control <?php echo e($errors->has('join_cgcc') ? 'is-invalid' : ''); ?>" name="join_cgcc" id="join_cgcc">
                    <option value disabled <?php echo e(old('join_cgcc', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\FirstTimer::JOIN_CGCC_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('join_cgcc', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('join_cgcc')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('join_cgcc')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.join_cgcc_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.firstTimer.fields.start_ats')); ?></label>
                <select class="form-control <?php echo e($errors->has('start_ats') ? 'is-invalid' : ''); ?>" name="start_ats" id="start_ats">
                    <option value disabled <?php echo e(old('start_ats', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\FirstTimer::START_ATS_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('start_ats', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('start_ats')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('start_ats')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.start_ats_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.firstTimer.fields.ats_mode')); ?></label>
                <select class="form-control <?php echo e($errors->has('ats_mode') ? 'is-invalid' : ''); ?>" name="ats_mode" id="ats_mode">
                    <option value disabled <?php echo e(old('ats_mode', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\FirstTimer::ATS_MODE_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('ats_mode', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('ats_mode')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('ats_mode')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.ats_mode_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="prayer_request"><?php echo e(trans('cruds.firstTimer.fields.prayer_request')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('prayer_request') ? 'is-invalid' : ''); ?>" name="prayer_request" id="prayer_request"><?php echo e(old('prayer_request')); ?></textarea>
                <?php if($errors->has('prayer_request')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('prayer_request')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.firstTimer.fields.prayer_request_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/firstTimers/create.blade.php ENDPATH**/ ?>