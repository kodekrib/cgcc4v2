<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('child_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.children.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.child.title_singular')); ?>

            </a>
        </div>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.child.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-mothersNameChildren">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.child.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.child.fields.position_in_family')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.child.fields.full_names')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.child.fields.mobile')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.child.fields.email')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.child.fields.relationship')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.child.fields.specify')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.child.fields.gender')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.child.fields.date_of_birth')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.child.fields.father_name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.child.fields.mothers_name')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($child->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($child->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($child->position_in_family ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($child->full_names ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($child->mobile ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($child->email ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\Child::RELATIONSHIP_SELECT[$child->relationship] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($child->specify ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\Child::GENDER_SELECT[$child->gender] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($child->date_of_birth ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($child->father_name->member_name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($child->mothers_name->member_name ?? ''); ?>

                            </td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('child_show')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.children.show', $child->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('child_edit')): ?>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.children.edit', $child->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('child_delete')): ?>
                                    <form action="<?php echo e(route('admin.children.destroy', $child->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                    </form>
                                <?php endif; ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('child_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.children.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 3, 'desc' ]],
    pageLength: 50,
  });
  let table = $('.datatable-mothersNameChildren:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/members/relationships/mothersNameChildren.blade.php ENDPATH**/ ?>