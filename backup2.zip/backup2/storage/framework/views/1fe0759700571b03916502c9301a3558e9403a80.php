<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    Dashboard
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dash_board_member_info')): ?>
                        <div class="<?php echo e($settings1['column_class']); ?>">
                            <div class="card text-white bg-primary">
                                <div class="card-body pb-0">
                                    <div class="text-value"><?php echo e(number_format($settings1['total_number'])); ?></div>
                                    <div><?php echo e($settings1['chart_title']); ?></div>
                                    <br />
                                </div>
                            </div>
                        </div>
                        <div class="<?php echo e($settings2['column_class']); ?>">
                            <div class="card text-white bg-primary">
                                <div class="card-body pb-0">
                                    <div class="text-value"><?php echo e(number_format($settings2['total_number'])); ?></div>
                                    <div><?php echo e($settings2['chart_title']); ?></div>
                                    <br />
                                </div>
                            </div>
                        </div>
                        <div class="<?php echo e($settings3['column_class']); ?>">
                            <div class="card text-white bg-primary">
                                <div class="card-body pb-0">
                                    <div class="text-value"><?php echo e(number_format($settings3['total_number'])); ?></div>
                                    <div><?php echo e($settings3['chart_title']); ?></div>
                                    <br />
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dash_board_venue_info')): ?>
                        <div class="<?php echo e($chart4->options['column_class']); ?>">
                            <h3><?php echo $chart4->options['chart_title']; ?></h3>
                            <?php echo $chart4->renderHtml(); ?>

                        </div>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dash_board_recent_member')): ?>
                        
                        <div class="<?php echo e($settings5['column_class']); ?>" style="overflow-x: auto;">
                            <h3><?php echo e($settings5['chart_title']); ?></h3>
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <?php $__currentLoopData = $settings5['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th>
                                                <?php echo e(trans(sprintf('cruds.%s.fields.%s', $settings5['translation_key'] ?? 'pleaseUpdateWidget', $key))); ?>

                                            </th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $settings5['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <?php $__currentLoopData = $settings5['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <?php if($value === ''): ?>
                                                        <?php echo e($entry->{$key}); ?>

                                                    <?php elseif(is_iterable($entry->{$key})): ?>
                                                        <?php $__currentLoopData = $entry->{$key}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subEentry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <span class="label label-info"><?php echo e($subEentry->{$value}); ?></span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <?php echo e(data_get($entry, $key . '.' . $value)); ?>

                                                    <?php endif; ?>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="<?php echo e(count($settings5['fields'])); ?>"><?php echo e(__('No entries found')); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dash_board_recent_appointment_booking')): ?>
                        
                        <div class="<?php echo e($settings6['column_class']); ?>" style="overflow-x: auto;">
                            <h3><?php echo e($settings6['chart_title']); ?></h3>
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <?php $__currentLoopData = $settings6['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th>
                                                <?php echo e(trans(sprintf('cruds.%s.fields.%s', $settings6['translation_key'] ?? 'pleaseUpdateWidget', $key))); ?>

                                            </th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $settings6['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <?php $__currentLoopData = $settings6['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <?php if($value === ''): ?>
                                                        <?php echo e($entry->{$key}); ?>

                                                    <?php elseif(is_iterable($entry->{$key})): ?>
                                                        <?php $__currentLoopData = $entry->{$key}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subEentry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <span class="label label-info"><?php echo e($subEentry->{$value}); ?></span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <?php echo e(data_get($entry, $key . '.' . $value)); ?>

                                                    <?php endif; ?>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="<?php echo e(count($settings6['fields'])); ?>"><?php echo e(__('No entries found')); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dash_board_recent_appointment_booking')): ?>
                        <div class="<?php echo e($settings7['column_class']); ?>">
                            <div class="card text-white bg-primary">
                                <div class="card-body pb-0">
                                    <div class="text-value"><?php echo e(number_format($settings7['total_number'])); ?></div>
                                    <div><?php echo e($settings7['chart_title']); ?></div>
                                    <br />
                                </div>
                            </div>
                        </div>
                        <div class="<?php echo e($chart8->options['column_class']); ?>">
                            <h3><?php echo $chart8->options['chart_title']; ?></h3>
                            <?php echo $chart8->renderHtml(); ?>

                        </div>
                        <div class="<?php echo e($chart9->options['column_class']); ?>">
                            <h3><?php echo $chart9->options['chart_title']; ?></h3>
                            <?php echo $chart9->renderHtml(); ?>

                        </div>
                        <div class="<?php echo e($chart10->options['column_class']); ?>">
                            <h3><?php echo $chart10->options['chart_title']; ?></h3>
                            <?php echo $chart10->renderHtml(); ?>

                        </div>
                        
                        <div class="<?php echo e($settings11['column_class']); ?>" style="overflow-x: auto;">
                            <h3><?php echo e($settings11['chart_title']); ?></h3>
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <?php $__currentLoopData = $settings11['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th>
                                                <?php echo e(trans(sprintf('cruds.%s.fields.%s', $settings11['translation_key'] ?? 'pleaseUpdateWidget', $key))); ?>

                                            </th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $settings11['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <?php $__currentLoopData = $settings11['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <?php if($value === ''): ?>
                                                        <?php echo e($entry->{$key}); ?>

                                                    <?php elseif(is_iterable($entry->{$key})): ?>
                                                        <?php $__currentLoopData = $entry->{$key}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subEentry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <span class="label label-info"><?php echo e($subEentry->{$value}); ?></span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <?php echo e(data_get($entry, $key . '.' . $value)); ?>

                                                    <?php endif; ?>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="<?php echo e(count($settings11['fields'])); ?>"><?php echo e(__('No entries found')); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="<?php echo e($settings12['column_class']); ?>">
                            <div class="card text-white bg-primary">
                                <div class="card-body pb-0">
                                    <div class="text-value"><?php echo e(number_format($settings12['total_number'])); ?></div>
                                    <div><?php echo e($settings12['chart_title']); ?></div>
                                    <br />
                                </div>
                            </div>
                        </div>
                        <div class="<?php echo e($settings13['column_class']); ?>">
                            <div class="card text-white bg-primary">
                                <div class="card-body pb-0">
                                    <div class="text-value"><?php echo e(number_format($settings13['total_number'])); ?></div>
                                    <div><?php echo e($settings13['chart_title']); ?></div>
                                    <br />
                                </div>
                            </div>
                        </div>
                        <div class="<?php echo e($settings14['column_class']); ?>">
                            <div class="card text-white bg-primary">
                                <div class="card-body pb-0">
                                    <div class="text-value"><?php echo e(number_format($settings14['total_number'])); ?></div>
                                    <div><?php echo e($settings14['chart_title']); ?></div>
                                    <br />
                                </div>
                            </div>
                        </div>
                        <div class="<?php echo e($settings15['column_class']); ?>">
                            <div class="card text-white bg-primary">
                                <div class="card-body pb-0">
                                    <div class="text-value"><?php echo e(number_format($settings15['total_number'])); ?></div>
                                    <div><?php echo e($settings15['chart_title']); ?></div>
                                    <br />
                                </div>
                            </div>
                        </div>
                        <div class="<?php echo e($settings16['column_class']); ?>">
                            <div class="card text-white bg-primary">
                                <div class="card-body pb-0">
                                    <div class="text-value"><?php echo e(number_format($settings16['total_number'])); ?></div>
                                    <div><?php echo e($settings16['chart_title']); ?></div>
                                    <br />
                                </div>
                            </div>
                        </div>
                        <div class="<?php echo e($settings17['column_class']); ?>">
                            <div class="card text-white bg-primary">
                                <div class="card-body pb-0">
                                    <div class="text-value"><?php echo e(number_format($settings17['total_number'])); ?></div>
                                    <div><?php echo e($settings17['chart_title']); ?></div>
                                    <br />
                                </div>
                            </div>
                        </div>
                        <div class="<?php echo e($chart18->options['column_class']); ?>">
                            <h3><?php echo $chart18->options['chart_title']; ?></h3>
                            <?php echo $chart18->renderHtml(); ?>

                        </div>
                        <div class="<?php echo e($chart19->options['column_class']); ?>">
                            <h3><?php echo $chart19->options['chart_title']; ?></h3>
                            <?php echo $chart19->renderHtml(); ?>

                        </div>
                        
                        <div class="<?php echo e($settings20['column_class']); ?>" style="overflow-x: auto;">
                            <h3><?php echo e($settings20['chart_title']); ?></h3>
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <?php $__currentLoopData = $settings20['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th>
                                                <?php echo e(trans(sprintf('cruds.%s.fields.%s', $settings20['translation_key'] ?? 'pleaseUpdateWidget', $key))); ?>

                                            </th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $settings20['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <?php $__currentLoopData = $settings20['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <?php if($value === ''): ?>
                                                        <?php echo e($entry->{$key}); ?>

                                                    <?php elseif(is_iterable($entry->{$key})): ?>
                                                        <?php $__currentLoopData = $entry->{$key}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subEentry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <span class="label label-info"><?php echo e($subEentry->{$value}); ?></span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <?php echo e(data_get($entry, $key . '.' . $value)); ?>

                                                    <?php endif; ?>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="<?php echo e(count($settings20['fields'])); ?>"><?php echo e(__('No entries found')); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dash_board_recent_issue_raised')): ?>
                        
                        <div class="<?php echo e($settings21['column_class']); ?>" style="overflow-x: auto;">
                            <h3><?php echo e($settings21['chart_title']); ?></h3>
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <?php $__currentLoopData = $settings21['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th>
                                                <?php echo e(trans(sprintf('cruds.%s.fields.%s', $settings21['translation_key'] ?? 'pleaseUpdateWidget', $key))); ?>

                                            </th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $settings21['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <?php $__currentLoopData = $settings21['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <?php if($value === ''): ?>
                                                        <?php echo e($entry->{$key}); ?>

                                                    <?php elseif(is_iterable($entry->{$key})): ?>
                                                        <?php $__currentLoopData = $entry->{$key}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subEentry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <span class="label label-info"><?php echo e($subEentry->{$value}); ?></span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <?php echo e(data_get($entry, $key . '.' . $value)); ?>

                                                    <?php endif; ?>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="<?php echo e(count($settings21['fields'])); ?>"><?php echo e(__('No entries found')); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php endif; ?>
                        <div class="<?php echo e($chart22->options['column_class']); ?>">
                            <h3><?php echo $chart22->options['chart_title']; ?></h3>
                            <?php echo $chart22->renderHtml(); ?>

                        </div>
                        
                        <div class="<?php echo e($settings23['column_class']); ?>" style="overflow-x: auto;">
                            <h3><?php echo e($settings23['chart_title']); ?></h3>
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <?php $__currentLoopData = $settings23['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th>
                                                <?php echo e(trans(sprintf('cruds.%s.fields.%s', $settings23['translation_key'] ?? 'pleaseUpdateWidget', $key))); ?>

                                            </th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $settings23['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <?php $__currentLoopData = $settings23['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <?php if($value === ''): ?>
                                                        <?php echo e($entry->{$key}); ?>

                                                    <?php elseif(is_iterable($entry->{$key})): ?>
                                                        <?php $__currentLoopData = $entry->{$key}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subEentry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <span class="label label-info"><?php echo e($subEentry->{$value}); ?></span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <?php echo e(data_get($entry, $key . '.' . $value)); ?>

                                                    <?php endif; ?>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="<?php echo e(count($settings23['fields'])); ?>"><?php echo e(__('No entries found')); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="<?php echo e($chart24->options['column_class']); ?>">
                            <h3><?php echo $chart24->options['chart_title']; ?></h3>
                            <?php echo $chart24->renderHtml(); ?>

                        </div>
                        
                        <div class="<?php echo e($settings25['column_class']); ?>" style="overflow-x: auto;">
                            <h3><?php echo e($settings25['chart_title']); ?></h3>
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <?php $__currentLoopData = $settings25['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th>
                                                <?php echo e(trans(sprintf('cruds.%s.fields.%s', $settings25['translation_key'] ?? 'pleaseUpdateWidget', $key))); ?>

                                            </th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $settings25['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <?php $__currentLoopData = $settings25['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <?php if($value === ''): ?>
                                                        <?php echo e($entry->{$key}); ?>

                                                    <?php elseif(is_iterable($entry->{$key})): ?>
                                                        <?php $__currentLoopData = $entry->{$key}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subEentry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <span class="label label-info"><?php echo e($subEentry->{$value}); ?></span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <?php echo e(data_get($entry, $key . '.' . $value)); ?>

                                                    <?php endif; ?>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="<?php echo e(count($settings25['fields'])); ?>"><?php echo e(__('No entries found')); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="<?php echo e($chart26->options['column_class']); ?>">
                            <h3><?php echo $chart26->options['chart_title']; ?></h3>
                            <?php echo $chart26->renderHtml(); ?>

                        </div>
                        <div class="<?php echo e($chart27->options['column_class']); ?>">
                            <h3><?php echo $chart27->options['chart_title']; ?></h3>
                            <?php echo $chart27->renderHtml(); ?>

                        </div>
                        <div class="<?php echo e($chart28->options['column_class']); ?>">
                            <h3><?php echo $chart28->options['chart_title']; ?></h3>
                            <?php echo $chart28->renderHtml(); ?>

                        </div>
                        
                        <div class="<?php echo e($settings29['column_class']); ?>" style="overflow-x: auto;">
                            <h3><?php echo e($settings29['chart_title']); ?></h3>
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <?php $__currentLoopData = $settings29['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th>
                                                <?php echo e(trans(sprintf('cruds.%s.fields.%s', $settings29['translation_key'] ?? 'pleaseUpdateWidget', $key))); ?>

                                            </th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $settings29['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <?php $__currentLoopData = $settings29['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <?php if($value === ''): ?>
                                                        <?php echo e($entry->{$key}); ?>

                                                    <?php elseif(is_iterable($entry->{$key})): ?>
                                                        <?php $__currentLoopData = $entry->{$key}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subEentry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <span class="label label-info"><?php echo e($subEentry->{$value}); ?></span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <?php echo e(data_get($entry, $key . '.' . $value)); ?>

                                                    <?php endif; ?>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="<?php echo e(count($settings29['fields'])); ?>"><?php echo e(__('No entries found')); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        
                        <div class="<?php echo e($settings30['column_class']); ?>" style="overflow-x: auto;">
                            <h3><?php echo e($settings30['chart_title']); ?></h3>
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <?php $__currentLoopData = $settings30['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th>
                                                <?php echo e(trans(sprintf('cruds.%s.fields.%s', $settings30['translation_key'] ?? 'pleaseUpdateWidget', $key))); ?>

                                            </th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $settings30['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <?php $__currentLoopData = $settings30['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <?php if($value === ''): ?>
                                                        <?php echo e($entry->{$key}); ?>

                                                    <?php elseif(is_iterable($entry->{$key})): ?>
                                                        <?php $__currentLoopData = $entry->{$key}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subEentry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <span class="label label-info"><?php echo e($subEentry->{$value}); ?></span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <?php echo e(data_get($entry, $key . '.' . $value)); ?>

                                                    <?php endif; ?>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="<?php echo e(count($settings30['fields'])); ?>"><?php echo e(__('No entries found')); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="<?php echo e($chart31->options['column_class']); ?>">
                            <h3><?php echo $chart31->options['chart_title']; ?></h3>
                            <?php echo $chart31->renderHtml(); ?>

                        </div>
                        <div class="<?php echo e($chart32->options['column_class']); ?>">
                            <h3><?php echo $chart32->options['chart_title']; ?></h3>
                            <?php echo $chart32->renderHtml(); ?>

                        </div>
                        <div class="<?php echo e($chart33->options['column_class']); ?>">
                            <h3><?php echo $chart33->options['chart_title']; ?></h3>
                            <?php echo $chart33->renderHtml(); ?>

                        </div>
                        <div class="<?php echo e($settings34['column_class']); ?>">
                            <div class="card text-white bg-primary">
                                <div class="card-body pb-0">
                                    <div class="text-value"><?php echo e(number_format($settings34['total_number'])); ?></div>
                                    <div><?php echo e($settings34['chart_title']); ?></div>
                                    <br />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script><?php echo $chart4->renderJs(); ?><?php echo $chart8->renderJs(); ?><?php echo $chart9->renderJs(); ?><?php echo $chart10->renderJs(); ?><?php echo $chart18->renderJs(); ?><?php echo $chart19->renderJs(); ?><?php echo $chart22->renderJs(); ?><?php echo $chart24->renderJs(); ?><?php echo $chart26->renderJs(); ?><?php echo $chart27->renderJs(); ?><?php echo $chart28->renderJs(); ?><?php echo $chart31->renderJs(); ?><?php echo $chart32->renderJs(); ?><?php echo $chart33->renderJs(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kodekribtech/Documents/mycitadel/resources/views/home.blade.php ENDPATH**/ ?>