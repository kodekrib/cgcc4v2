<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('empowerment_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.empowerments.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.empowerment.title_singular')); ?>

            </a>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.empowerment.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-Empowerment">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.empowerment.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.empowerment.fields.ats_membership_no')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.atsMembershipRecord.fields.ats_membership_no')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.empowerment.fields.cooperative')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.empowerment.fields.contribution_amount')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.empowerment.fields.contribution_frequency')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.empowerment.fields.start_year')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.empowerment.fields.start_month')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.empowerment.fields.business_advisory')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.empowerment.fields.advisory_team')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.empowerment.fields.trainings')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.empowerment.fields.training_needs')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $empowerments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $empowerment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($empowerment->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($empowerment->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($empowerment->ats_membership_no->names ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($empowerment->ats_membership_no->ats_membership_no ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\Empowerment::COOPERATIVE_SELECT[$empowerment->cooperative] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($empowerment->contribution_amount  ?? 'N/A'); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\Empowerment::CONTRIBUTION_FREQUENCY_SELECT[$empowerment->contribution_frequency] ?? 'N/A'); ?>

                            </td>
                            <td>
                                <?php echo e($empowerment->start_year ?? 'N/A'); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\Empowerment::START_MONTH_SELECT[$empowerment->start_month] ?? 'N/A'); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\Empowerment::BUSINESS_ADVISORY_SELECT[$empowerment->business_advisory] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($empowerment->advisory_team ?? 'N/A'); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\Empowerment::TRAININGS_SELECT[$empowerment->trainings] ?? ''); ?>

                            </td>
                            <td>
                                <?php $__currentLoopData = $empowerment->training_needs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge badge-info"><?php echo e($item->training_needs); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('empowerment_show')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.empowerments.show', $empowerment->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('empowerment_edit')): ?>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.empowerments.edit', $empowerment->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>


                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 50,
  });
  let table = $('.datatable-Empowerment:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });

})

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kodekribtech/Documents/mycitadel/resources/views/admin/empowerments/index.blade.php ENDPATH**/ ?>