
<!-- <div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.mailingSetup.title_singular')); ?>

    </div>

    <div class="card-body"> -->
        <!-- <form method="POST" action="<?php echo e(route("admin.members.store")); ?>" enctype="multipart/form-data"> -->


            <div class="row">
                <div class="col-6 form-group">
                        <label class="required" for="operationCode"><?php echo e(trans('cruds.mailingSetup.fields.mailing_operation_name')); ?></label>
                        <select class="form-control <?php echo e($errors->has('mailing_operation_code') ? 'is-invalid' : ''); ?>" name="mailing_operation_code" id="mailing_operation_code" required onchange="OnchangeOperationCode()">
                        <option value disabled <?php echo e(old('mailing_operation_code', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                        <?php $__currentLoopData = App\Models\Member::MAILING_SETUP_OPERATION_CODE; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php echo e(old('mailing_operation_code', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('mailing_operation_code')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('mailing_operation_code')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.mailingSetup.fields.mailing_operation_code')); ?></span>
                </div>
                <div class="col-6 form-group">
                        <label  for="number_email"><?php echo e(trans('cruds.mailingSetup.fields.number_email')); ?></label>
                        <input class="form-control <?php echo e($errors->has('number_email') ? 'is-invalid' : ''); ?>" type="text" name="number_email" id="number_email" value="<?php echo e(old('number_email', '')); ?>" onchange="Number_Email_change()">
                        <?php if($errors->has('number_email')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('number_email')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.mailingSetup.fields.mailing_operation_code')); ?></span>
                </div>
            </div>
            <div style="height: 50px;">
                <button class="btn btn-success pull-right"  onclick="AddEmailSetting()" style="display: none;" id="btnAdd">
                    <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.mailingSetup.title_singular')); ?>

                </button>
            </div>


            <div id="emailCOntainer">
                <!-- <div class="shadow p-3 mb-5 bg-white rounded">
                    <div class ="row">
                        <div class="col-4 form-group">
                            <label class="required" for="operationCode"><?php echo e(trans('cruds.mailingSetup.fields.category')); ?></label>
                            <select class="form-control">
                                <option value disabled selected><?php echo e(trans('global.pleaseSelect')); ?></option>
                            </select>

                        </div>

                        <div class="col-4 form-group">
                            <label class="required" for="operationCode"><?php echo e(trans('cruds.mailingSetup.fields.memberName')); ?></label>
                            <select class="form-control" id="example-getting-started">
                                <option value disabled selected><?php echo e(trans('global.pleaseSelect')); ?></option>
                            </select>

                        </div>
                    </div>
                </div> -->
            </div>
            <div style="height: 50px;">
                <button class="btn btn-success pull-right" onclick="submitMailSetup()" style="display: none;" id="btnSubmit">
                    Submit
                </button>
            </div>


        <!-- </form> -->
    <!-- </div>
</div> -->


<?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/mailingSetup/create.blade.php ENDPATH**/ ?>