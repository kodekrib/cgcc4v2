<?php $__env->startSection('content'); ?>
<div id="login_left">
		<div class="inners">
			<div id="logo">
      			<img src="images/CGCC_logo.png">
    		</div>
			<div id="captions">
				<span>Welcome to The Citadel Global Community Church</span>
				<h2>An Intentional Community with Dynamic Influence</h2>
			</div>
		</div>
	</div>
	<div id="login_right">
		<div class="inners">
			<div id="login_panel">
				<h3>Login to your account</h3>
				<span>Enter your information below to login</span>
              		<?php if(session('message')): ?>
				<div class="alert alert-info" role="alert">
					<?php echo e(session('message')); ?>

				</div>
			<?php endif; ?>
                <form method="POST" action="<?php echo e(route('userLogin')); ?>">
                  <?php echo csrf_field(); ?>
					<label>Phone Number or Email Address</label>
					<input type="text" id="email" name="email" class="auths" required autofocus placeholder="<?php echo e(trans('Enter Phone Number or Email Address')); ?>">
                  	<?php if($errors->has('email')): ?>
					<div class="invalid-feedback">
						<?php echo e($errors->first('email')); ?>

					</div>
				<?php endif; ?>
                  	<input type="submit" name="Login via a magic link" value="Login via a magic link" class="auths2">
				</form>
				<div id="nuser">New User? <a href="<?php echo e(route('register')); ?>">Register</a></div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<style>
    .invalid-feedback {
        color: red;
    }
	.alert-info {
    	background-color: #c7d2f5;
    }
</style>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kodekribtech/Documents/mycitadel/resources/views/auth/login.blade.php ENDPATH**/ ?>