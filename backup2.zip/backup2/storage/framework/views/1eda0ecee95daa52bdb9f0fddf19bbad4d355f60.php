<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.qualificationSetting.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.qualification-settings.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="highest_qualification"><?php echo e(trans('cruds.qualificationSetting.fields.highest_qualification')); ?></label>
                <input class="form-control <?php echo e($errors->has('highest_qualification') ? 'is-invalid' : ''); ?>" type="text" name="highest_qualification" id="highest_qualification" value="<?php echo e(old('highest_qualification', '')); ?>" required>
                <?php if($errors->has('highest_qualification')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('highest_qualification')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.qualificationSetting.fields.highest_qualification_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kodekribtech/Documents/mycitadel/resources/views/admin/qualificationSettings/create.blade.php ENDPATH**/ ?>