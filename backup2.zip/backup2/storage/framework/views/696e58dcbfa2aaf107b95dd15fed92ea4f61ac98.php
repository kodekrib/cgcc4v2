<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.venueAccessory.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.venue-accessories.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="accessories"><?php echo e(trans('cruds.venueAccessory.fields.accessories')); ?></label>
                <input class="form-control <?php echo e($errors->has('accessories') ? 'is-invalid' : ''); ?>" type="text" name="accessories" id="accessories" value="<?php echo e(old('accessories', '')); ?>" required>
                <?php if($errors->has('accessories')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('accessories')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.venueAccessory.fields.accessories_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/venueAccessories/create.blade.php ENDPATH**/ ?>