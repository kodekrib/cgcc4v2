<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('outreach_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.outreaches.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.outreach.title_singular')); ?>

            </a>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.outreach.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-Outreach">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.outreach.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.outreach.fields.type')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.outreach.fields.name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.outreach.fields.description')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.outreach.fields.date')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.outreach.fields.time')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.outreach.fields.location')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.outreach.fields.contact_person')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.user.fields.name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.user.fields.firstname')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.user.fields.mobile')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.outreach.fields.active')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.outreach.fields.completed')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $outreaches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $outreach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($outreach->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($outreach->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($outreach->type->type ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($outreach->name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($outreach->description ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($outreach->date ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($outreach->time ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($outreach->location->location ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($outreach->contact_person->email ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($outreach->contact_person->name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($outreach->contact_person->firstname ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($outreach->contact_person->mobile ?? ''); ?>

                            </td>
                            <td>
                                <span style="display:none"><?php echo e($outreach->active ?? ''); ?></span>
                                <input type="checkbox" disabled="disabled" <?php echo e($outreach->active ? 'checked' : ''); ?>>
                            </td>
                            <td>
                                <span style="display:none"><?php echo e($outreach->completed ?? ''); ?></span>
                                <input type="checkbox" disabled="disabled" <?php echo e($outreach->completed ? 'checked' : ''); ?>>
                            </td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('outreach_show')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.outreaches.show', $outreach->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('outreach_edit')): ?>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.outreaches.edit', $outreach->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('outreach_delete')): ?>
                                    <form action="<?php echo e(route('admin.outreaches.destroy', $outreach->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                    </form>
                                <?php endif; ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('outreach_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.outreaches.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 50,
  });
  let table = $('.datatable-Outreach:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/outreaches/index.blade.php ENDPATH**/ ?>