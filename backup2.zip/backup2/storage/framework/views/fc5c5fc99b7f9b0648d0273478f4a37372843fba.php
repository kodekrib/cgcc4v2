<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.goal.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.goals.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="date"><?php echo e(trans('cruds.goal.fields.date')); ?></label>
                <input class="form-control date <?php echo e($errors->has('date') ? 'is-invalid' : ''); ?>" type="text" name="date" id="date" value="<?php echo e(old('date')); ?>">
                <?php if($errors->has('date')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('date')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.goal.fields.date_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="goal_name"><?php echo e(trans('cruds.goal.fields.goal_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('goal_name') ? 'is-invalid' : ''); ?>" type="text" name="goal_name" id="goal_name" value="<?php echo e(old('goal_name', '')); ?>">
                <?php if($errors->has('goal_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('goal_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.goal.fields.goal_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="note"><?php echo e(trans('cruds.goal.fields.note')); ?></label>
                <textarea class="form-control ckeditor <?php echo e($errors->has('note') ? 'is-invalid' : ''); ?>" name="note" id="note"><?php echo old('note'); ?></textarea>
                <?php if($errors->has('note')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('note')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.goal.fields.note_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="achievement_date"><?php echo e(trans('cruds.goal.fields.achievement_date')); ?></label>
                <input class="form-control date <?php echo e($errors->has('achievement_date') ? 'is-invalid' : ''); ?>" type="text" name="achievement_date" id="achievement_date" value="<?php echo e(old('achievement_date')); ?>">
                <?php if($errors->has('achievement_date')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('achievement_date')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.goal.fields.achievement_date_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="goal_kpi"><?php echo e(trans('cruds.goal.fields.goal_kpi')); ?></label>
                <input class="form-control <?php echo e($errors->has('goal_kpi') ? 'is-invalid' : ''); ?>" type="text" name="goal_kpi" id="goal_kpi" value="<?php echo e(old('goal_kpi', '')); ?>">
                <?php if($errors->has('goal_kpi')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('goal_kpi')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.goal.fields.goal_kpi_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
  function SimpleUploadAdapter(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = function(loader) {
      return {
        upload: function() {
          return loader.file
            .then(function (file) {
              return new Promise(function(resolve, reject) {
                // Init request
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo e(route('admin.goals.storeCKEditorImages')); ?>', true);
                xhr.setRequestHeader('x-csrf-token', window._token);
                xhr.setRequestHeader('Accept', 'application/json');
                xhr.responseType = 'json';

                // Init listeners
                var genericErrorText = `Couldn't upload file: ${ file.name }.`;
                xhr.addEventListener('error', function() { reject(genericErrorText) });
                xhr.addEventListener('abort', function() { reject() });
                xhr.addEventListener('load', function() {
                  var response = xhr.response;

                  if (!response || xhr.status !== 201) {
                    return reject(response && response.message ? `${genericErrorText}\n${xhr.status} ${response.message}` : `${genericErrorText}\n ${xhr.status} ${xhr.statusText}`);
                  }

                  $('form').append('<input type="hidden" name="ck-media[]" value="' + response.id + '">');

                  resolve({ default: response.url });
                });

                if (xhr.upload) {
                  xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                      loader.uploadTotal = e.total;
                      loader.uploaded = e.loaded;
                    }
                  });
                }

                // Send request
                var data = new FormData();
                data.append('upload', file);
                data.append('crud_id', '<?php echo e($goal->id ?? 0); ?>');
                xhr.send(data);
              });
            })
        }
      };
    }
  }

  var allEditors = document.querySelectorAll('.ckeditor');
  for (var i = 0; i < allEditors.length; ++i) {
    ClassicEditor.create(
      allEditors[i], {
        extraPlugins: [SimpleUploadAdapter]
      }
    );
  }
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kodekribtech/Documents/mycitadel/resources/views/admin/goals/create.blade.php ENDPATH**/ ?>