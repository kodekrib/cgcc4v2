<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.child.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.children.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="position_in_family"><?php echo e(trans('cruds.child.fields.position_in_family')); ?></label>
                <input class="form-control <?php echo e($errors->has('position_in_family') ? 'is-invalid' : ''); ?>" type="number" name="position_in_family" id="position_in_family" value="<?php echo e(old('position_in_family', '')); ?>" step="1">
                <?php if($errors->has('position_in_family')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('position_in_family')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.child.fields.position_in_family_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="full_names"><?php echo e(trans('cruds.child.fields.full_names')); ?></label>
                <input class="form-control <?php echo e($errors->has('full_names') ? 'is-invalid' : ''); ?>" type="text" name="full_names" id="full_names" value="<?php echo e(old('full_names', '')); ?>" required>
                <?php if($errors->has('full_names')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('full_names')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.child.fields.full_names_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="mobile"><?php echo e(trans('cruds.child.fields.mobile')); ?></label>
                <input class="form-control <?php echo e($errors->has('mobile') ? 'is-invalid' : ''); ?>" type="text" name="mobile" id="mobile" value="<?php echo e(old('mobile', '')); ?>">
                <?php if($errors->has('mobile')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('mobile')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.child.fields.mobile_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="email"><?php echo e(trans('cruds.child.fields.email')); ?></label>
                <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="email" name="email" id="email" value="<?php echo e(old('email')); ?>">
                <?php if($errors->has('email')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('email')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.child.fields.email_helper')); ?></span>
            </div>
            <div class="form-group" id="relationship">
                <label><?php echo e(trans('cruds.child.fields.relationship')); ?></label>
                <select class="form-control <?php echo e($errors->has('relationship') ? 'is-invalid' : ''); ?>" name="relationship">
                  <option value disabled <?php echo e(old('relationship', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                  <option value="Daughter" <?php echo e(old('relationship', '') === 'Daughter' ? 'selected' : ''); ?>>Daughter</option>
                  <option value="Son" <?php echo e(old('relationship', '') === 'Son' ? 'selected' : ''); ?>>Son</option>
                  <option value="Step Son" <?php echo e(old('relationship', '') === 'Step Son' ? 'selected' : ''); ?>>Step Son</option>
                  <option value="Step Daughter" <?php echo e(old('relationship', '') === 'Step Daughter' ? 'selected' : ''); ?>>Step Daughter</option>
                  <option value="Other" <?php echo e(old('relationship', '') === 'Other' ? 'selected' : ''); ?>>Other</option>
                </select>
                <?php if($errors->has('relationship')): ?>
                  <div class="invalid-feedback">
                    <?php echo e($errors->first('relationship')); ?>

                  </div>
                <?php endif; ?>
              </div>
            <div class="form-group" id="specify" style="display: none;">
                <label for="specify">If Other, Please Specify</label>
                <input class="form-control" type="text" name="specify">
            </div>
            
            <div class="form-group">
                <label><?php echo e(trans('cruds.child.fields.gender')); ?></label>
                <select class="form-control <?php echo e($errors->has('gender') ? 'is-invalid' : ''); ?>" name="gender" id="gender">
                    <option value disabled <?php echo e(old('gender', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Child::GENDER_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('gender', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('gender')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('gender')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.child.fields.gender_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="date_of_birth"><?php echo e(trans('cruds.child.fields.date_of_birth')); ?></label>
                <input class="form-control date <?php echo e($errors->has('date_of_birth') ? 'is-invalid' : ''); ?>" type="text" name="date_of_birth" id="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>" required>
                <?php if($errors->has('date_of_birth')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('date_of_birth')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.child.fields.date_of_birth_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="father_name_id"><?php echo e(trans('cruds.child.fields.father_name')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('father_name') ? 'is-invalid' : ''); ?>" name="father_name_id" id="father_name_id" required>
                    <?php $__currentLoopData = $father_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('father_name_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('father_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('father_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.child.fields.father_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="mothers_name_id"><?php echo e(trans('cruds.child.fields.mothers_name')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('mothers_name') ? 'is-invalid' : ''); ?>" name="mothers_name_id" id="mothers_name_id" required>
                    <?php $__currentLoopData = $mothers_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('mothers_name_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('mothers_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('mothers_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.child.fields.mothers_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>

<script>
    const relationshipSelect = document.querySelector('select[name="relationship"]');
    const specify = document.querySelector('#specify');
  
    relationshipSelect.addEventListener('change', function() {
      if (this.value === 'Other') {
        specify.style.display = 'block';
      } else {
        specify.style.display = 'none';
      }
    });
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/children/create.blade.php ENDPATH**/ ?>