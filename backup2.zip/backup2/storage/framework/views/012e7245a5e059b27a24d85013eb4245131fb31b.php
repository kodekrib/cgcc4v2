<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.cihmember.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.cihmembers.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="zone_id"><?php echo e(trans('cruds.cihmember.fields.zone')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('zone') ? 'is-invalid' : ''); ?>" name="zone_id" id="zone_id">
                    <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('zone_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('zone')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('zone')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.cihmember.fields.zone_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="cih_id"><?php echo e(trans('cruds.cihmember.fields.cih')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('cih') ? 'is-invalid' : ''); ?>" name="cih_id" id="cih_id">
                    <?php $__currentLoopData = $cihs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('cih_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('cih')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('cih')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.cihmember.fields.cih_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/cihmembers/create.blade.php ENDPATH**/ ?>