<?php $__env->startSection('content'); ?>
<div id="login_left">
		<div class="inners">
			<div id="logo">
      			<img src="images/CGCC_logo.png">
    		</div>
			<div id="captions">
				<span>Welcome to The Citadel Global Community Church</span>
				<h2>An Intentional Community with Dynamic Influence</h2>
			</div>
		</div>
	</div>
	<div id="login_right">
		<div class="inners">
			<div id="login_panel">
                <h3>A link has been sent to your email</h3>
				<span>Check your email for a link to log into your account</span>
              	<div id="nuser">If you didn't receive login email after 5 mins, goto  <a href="<?php echo e(route('login')); ?>"">Login page</a> to request a new one...</div>

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<style>
    .invalid-feedback {
        color: red;
    }
	.alert-info {
    	background-color: #c7d2f5;
    }
</style>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kodekribtech/Documents/mycitadel/resources/views/auth/login-sent.blade.php ENDPATH**/ ?>