<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.empowerment.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.empowerments.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="ats_membership_no_id"><?php echo e(trans('cruds.empowerment.fields.ats_membership_no')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('ats_membership_no') ? 'is-invalid' : ''); ?>" name="ats_membership_no_id" id="ats_membership_no_id">
                    <?php $__currentLoopData = $ats_membership_nos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('ats_membership_no_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('ats_membership_no')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('ats_membership_no')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.empowerment.fields.ats_membership_no_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.empowerment.fields.cooperative')); ?></label>
                <select class="form-control <?php echo e($errors->has('cooperative') ? 'is-invalid' : ''); ?>" name="cooperative" id="cooperative" required onchange="onCooperativeSelected()">
                    <option value disabled <?php echo e(old('cooperative', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Empowerment::COOPERATIVE_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('cooperative', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('cooperative')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('cooperative')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.empowerment.fields.cooperative_helper')); ?></span>
            </div>
            <div id="container_coperative">
                <div class="form-group">
                    <label class="required" for="contribution_amount"><?php echo e(trans('cruds.empowerment.fields.contribution_amount')); ?></label>
                    <input class="form-control <?php echo e($errors->has('contribution_amount') ? 'is-invalid' : ''); ?>" type="number" name="contribution_amount" id="contribution_amount" value="<?php echo e(old('contribution_amount', '0.00')); ?>" step="0.01">
                    <?php if($errors->has('contribution_amount')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('contribution_amount')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.empowerment.fields.contribution_amount_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label class="required"><?php echo e(trans('cruds.empowerment.fields.contribution_frequency')); ?></label>
                    <select class="form-control <?php echo e($errors->has('contribution_frequency') ? 'is-invalid' : ''); ?>" name="contribution_frequency" id="contribution_frequency" >
                        <option value disabled <?php echo e(old('contribution_frequency', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                        <?php $__currentLoopData = App\Models\Empowerment::CONTRIBUTION_FREQUENCY_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php echo e(old('contribution_frequency', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('contribution_frequency')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('contribution_frequency')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.empowerment.fields.contribution_frequency_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label class="required" for="start_year"><?php echo e(trans('cruds.empowerment.fields.start_year')); ?></label>
                    <input class="form-control <?php echo e($errors->has('start_year') ? 'is-invalid' : ''); ?>" type="number" name="start_year" id="start_year" value="<?php echo e(old('start_year', '2023')); ?>" step="1" >
                    <?php if($errors->has('start_year')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('start_year')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.empowerment.fields.start_year_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label class="required"><?php echo e(trans('cruds.empowerment.fields.start_month')); ?></label>
                    <select class="form-control <?php echo e($errors->has('start_month') ? 'is-invalid' : ''); ?>" name="start_month" id="start_month" >
                        <option value disabled <?php echo e(old('start_month', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                        <?php $__currentLoopData = App\Models\Empowerment::START_MONTH_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php echo e(old('start_month', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('start_month')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('start_month')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.empowerment.fields.start_month_helper')); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.empowerment.fields.business_advisory')); ?></label>
                <select class="form-control <?php echo e($errors->has('business_advisory') ? 'is-invalid' : ''); ?>" name="business_advisory" id="business_advisory" required onchange="onAdvisoryTeamSelected()">
                    <option value disabled <?php echo e(old('business_advisory', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Empowerment::BUSINESS_ADVISORY_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('business_advisory', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('business_advisory')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('business_advisory')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.empowerment.fields.business_advisory_helper')); ?></span>
            </div>
            <div class="form-group" id="container_advisory_team">
                <label for="advisory_team"><?php echo e(trans('cruds.empowerment.fields.advisory_team')); ?></label>
                <input class="form-control <?php echo e($errors->has('advisory_team') ? 'is-invalid' : ''); ?>" type="text" name="advisory_team" id="advisory_team" value="<?php echo e(old('advisory_team', '')); ?>" >
                <?php if($errors->has('advisory_team')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('advisory_team')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.empowerment.fields.advisory_team_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.empowerment.fields.trainings')); ?></label>
                <select class="form-control <?php echo e($errors->has('trainings') ? 'is-invalid' : ''); ?>" name="trainings" id="trainings" onchange="onTrainingNeedsSelected()">
                    <option value disabled <?php echo e(old('trainings', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Empowerment::TRAININGS_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('trainings', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('trainings')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('trainings')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.empowerment.fields.trainings_helper')); ?></span>
            </div>
            <div class="form-group" id="container_training_needs">
                <label for="training_needs"><?php echo e(trans('cruds.empowerment.fields.training_needs')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('training_needs') ? 'is-invalid' : ''); ?>" name="training_needs[]" id="training_needs" multiple>
                    <?php $__currentLoopData = $training_needs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $training_need): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(in_array($id, old('training_needs', [])) ? 'selected' : ''); ?>><?php echo e($training_need); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('training_needs')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('training_needs')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.empowerment.fields.training_needs_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
         function onAdvisoryTeamSelected(){
            const advisory_teamOpt = $('#business_advisory').val();
            if(advisory_teamOpt == 'yes'){
                document.getElementById('container_advisory_team').style.display = 'block';
            } else {
                document.getElementById('container_advisory_team').style.display = 'none';
                $('#advisory_team').val(null);

            }
         }

         function onTrainingNeedsSelected(){
            const training_needsOpt = $('#trainings').val();
            if(training_needsOpt == 'yes'){
                document.getElementById('container_training_needs').style.display = 'block';
            } else {
                document.getElementById('container_training_needs').style.display = 'none';
                $('#training_needs').val(null);

            }
         }
        function onCooperativeSelected(){
            const cooperativeOpt = $('#cooperative').val();
            if(cooperativeOpt == 'yes'){
                document.getElementById('container_coperative').style.display = 'block';
            } else {
                document.getElementById('container_coperative').style.display = 'none';
                $('#contribution_amount').val(0);
                $('#contribution_frequency').val(null);
                $('#start_year').val(new Date().getFullYear());
                $('#start_month').val(null);
            }
        }
        $(document ).ready(() =>{
            onCooperativeSelected();
            onAdvisoryTeamSelected();
            onTrainingNeedsSelected();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kodekribtech/Documents/mycitadel/resources/views/admin/empowerments/create.blade.php ENDPATH**/ ?>