<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.typeOfAppoinment.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.type-of-appoinments.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="type"><?php echo e(trans('cruds.typeOfAppoinment.fields.type')); ?></label>
                <input class="form-control <?php echo e($errors->has('type') ? 'is-invalid' : ''); ?>" type="text" name="type" id="type" value="<?php echo e(old('type', '')); ?>">
                <?php if($errors->has('type')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('type')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.typeOfAppoinment.fields.type_helper')); ?></span>
            </div>

            <div class="form-group">
                <label class="required" for="members_in_attendances">Member To manage the type</label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('members_list') ? 'is-invalid' : ''); ?>" name="members_list[]" id="members_list" multiple required onchange="onManage()">
                    <?php $__currentLoopData = $memberManageAppointmentType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $members_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(in_array($id, old('members_list', [])) ? 'selected' : ''); ?>><?php echo e($members_item); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('members_list')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('members_list')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.attendanceManagement.fields.members_in_attendance_helper')); ?></span>
            </div>
            <div class="form-group">
                <label>Default Member</label>
                <select class="form-control <?php echo e($errors->has('default_members_id') ? 'is-invalid' : ''); ?>" name="default_members_id" id="default_members_id">
                    <option value disabled <?php echo e(old('default_members_id', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = $memberManageAppointmentType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(collect(old('members_list'))->contains($key)): ?>
                            <option value="<?php echo e($key); ?>" <?php echo e(old('default_members_id', '') ===  $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('age_category')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('age_category')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.attendanceManagement.fields.age_category_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    var memberList = JSON.parse('<?php echo e(json_encode($memberManageAppointmentType)); ?>'.replace(/&quot;/g,'"'));
    function onManage(){
        var list = $('#members_list').toArray().map(item => item.value);
        $('#default_members_id').empty();
        $('#default_members_id').append($('<option>', { value: '', text: '<?php echo e(trans('global.pleaseSelect')); ?>' }))
        $.each(memberList, (index, value) => {
            const cke = list.find(x => x === index);
            if(cke !== null && cke !== undefined){
                $('#default_members_id').append($('<option>', { value: index, text: value }))
            }
        });
    }
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/typeOfAppoinments/create.blade.php ENDPATH**/ ?>