<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.interest.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.interests.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="interests"><?php echo e(trans('cruds.interest.fields.interests')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('interests') ? 'is-invalid' : ''); ?>" name="interests[]" id="interests" multiple>
                    <?php $__currentLoopData = $interests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $interest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(in_array($id, old('interests', [])) ? 'selected' : ''); ?>><?php echo e($interest); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('interests')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('interests')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.interest.fields.interests_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="other_sports"><?php echo e(trans('cruds.interest.fields.other_sports')); ?></label>
                <input class="form-control <?php echo e($errors->has('other_sports') ? 'is-invalid' : ''); ?>" type="text" name="other_sports" id="other_sports" value="<?php echo e(old('other_sports', '')); ?>">
                <?php if($errors->has('other_sports')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('other_sports')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.interest.fields.other_sports_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="social_causes"><?php echo e(trans('cruds.interest.fields.social_causes')); ?></label>
                <input class="form-control <?php echo e($errors->has('social_causes') ? 'is-invalid' : ''); ?>" type="text" name="social_causes" id="social_causes" value="<?php echo e(old('social_causes', '')); ?>">
                <?php if($errors->has('social_causes')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('social_causes')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.interest.fields.social_causes_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="entrepreneurial_interests"><?php echo e(trans('cruds.interest.fields.entrepreneurial_interests')); ?></label>
                <input class="form-control <?php echo e($errors->has('entrepreneurial_interests') ? 'is-invalid' : ''); ?>" type="text" name="entrepreneurial_interests" id="entrepreneurial_interests" value="<?php echo e(old('entrepreneurial_interests', '')); ?>">
                <?php if($errors->has('entrepreneurial_interests')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('entrepreneurial_interests')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.interest.fields.entrepreneurial_interests_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="industry_sector_id"><?php echo e(trans('cruds.interest.fields.industry_sector')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('industry_sector') ? 'is-invalid' : ''); ?>" name="industry_sector_id" id="industry_sector_id">
                    <?php $__currentLoopData = $industry_sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('industry_sector_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('industry_sector')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('industry_sector')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.interest.fields.industry_sector_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kodekribtech/Documents/mycitadel/resources/views/admin/interests/create.blade.php ENDPATH**/ ?>