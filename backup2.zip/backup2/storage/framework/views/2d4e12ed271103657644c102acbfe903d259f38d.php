<?php $__env->startSection('content'); ?>
<div id="login_left">
		<div class="inners">
			<div id="logo">
      			<img src="images/CGCC_logo.png">
    		</div>
			<div id="captions">
				<span>Welcome to The Citadel Global Community Church</span>
				<h2>An Intentional Community with Dynamic Influence</h2>
			</div>
		</div>
	</div>
	<div id="login_right">
		<div class="inners">
			<div id="login_panel">
				<h3>Register your account</h3>
				<span>Enter your information below to register</span>
				<form method="POST" action="<?php echo e(route('register')); ?>">
                  <?php echo e(csrf_field()); ?>

					<label>Surname
						<input type="text" name="name" class="auths" required autofocus placeholder="<?php echo e(trans('Enter Surname')); ?>">
                      		<?php if($errors->has('name')): ?>
						<div class="invalid-feedback">
							<?php echo e($errors->first('name')); ?>

						</div>
					<?php endif; ?>
					</label>
					<label>Firstname
						<input type="text" name="firstname" class="auths" required autofocus placeholder="<?php echo e(trans('Enter First Name')); ?>">
                      		<?php if($errors->has('firstname')): ?>
						<div class="invalid-feedback">
							<?php echo e($errors->first('firstname')); ?>

						</div>
					<?php endif; ?>
					</label>
					<label>Email Address
						<input type="email" name="email" class="auths" required placeholder="<?php echo e(trans('Enter Email Address')); ?>">
                            <?php if($errors->has('email')): ?>
						<div class="invalid-feedback">
							<?php echo e($errors->first('email')); ?>

						</div>
					<?php endif; ?>
					</label>
					<label>Phone Number
						<input type="tel" name="mobile" class="auths" required placeholder="<?php echo e(trans('Enter Mobile Number')); ?>">
                            <?php if($errors->has('mobile')): ?>
						<div class="invalid-feedback">
							<?php echo e($errors->first('mobile')); ?>

						</div>
					<?php endif; ?>
					</label>
					<input type="checkbox" class="cbutton" name="policy" id="policy" value="1" required <?php echo e(old('policy', 0) == 1 || old('policy') === null ? 'unchecked' : ''); ?>> I agree to CGCC  <a href="">Privacy Policy</a>
					<input type="submit" name="Continue" value="Register" class="auths2">
				</form>
				<div id="nuser">Already a User? <a href="<?php echo e(route('login')); ?>"">Login</a></div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<style>
    .invalid-feedback {
        color: red;
    }
</style>
           
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/auth/register.blade.php ENDPATH**/ ?>