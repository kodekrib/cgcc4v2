<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.mailing.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.mailings.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label><?php echo e(trans('cruds.mailing.fields.job_mailing_list')); ?></label>
                <select class="form-control <?php echo e($errors->has('job_mailing_list') ? 'is-invalid' : ''); ?>" name="job_mailing_list" id="job_mailing_list" onchange="onSelectJobMailingList()">
                    <option value disabled <?php echo e(old('job_mailing_list', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Mailing::JOB_MAILING_LIST_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('job_mailing_list', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('job_mailing_list')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('job_mailing_list')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.mailing.fields.job_mailing_list_helper')); ?></span>
            </div>
            <div class="form-group" id="container_area_of_specialization_id">
                <label for="area_of_specialization_id"><?php echo e(trans('cruds.mailing.fields.area_of_specialization')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('area_of_specialization') ? 'is-invalid' : ''); ?>" name="area_of_specialization_id" id="area_of_specialization_id">
                    <?php $__currentLoopData = $area_of_specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('area_of_specialization_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('area_of_specialization')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('area_of_specialization')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.mailing.fields.area_of_specialization_helper')); ?></span>
            </div>
            <div class="form-group" id="conatiner_job_level_id">
                <label for="job_level_id"><?php echo e(trans('cruds.mailing.fields.job_level')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('job_level') ? 'is-invalid' : ''); ?>" name="job_level_id" id="job_level_id">
                    <?php $__currentLoopData = $job_levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('job_level_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('job_level')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('job_level')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.mailing.fields.job_level_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script>
        function onSelectJobMailingList(){
            const opt = $('#job_mailing_list').val();

            if(opt == 'yes'){
                document.getElementById('container_area_of_specialization_id').style.display = 'block';
                document.getElementById('conatiner_job_level_id').style.display = 'block';
            } else {
                document.getElementById('container_area_of_specialization_id').style.display = 'none';
                document.getElementById('conatiner_job_level_id').style.display = 'none';
                $('#area_of_specialization_id').val('');
                $('#job_level_id').val('');
            }
        }

        $(document ).ready(() =>{
            document.getElementById('container_area_of_specialization_id').style.display = 'none';
                document.getElementById('conatiner_job_level_id').style.display = 'none';
        });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kodekribtech/Documents/mycitadel/resources/views/admin/mailings/create.blade.php ENDPATH**/ ?>