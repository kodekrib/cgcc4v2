<div class="row">
    <div class="col-6 form-group">
        <label class="required" for="operationCode"><?php echo e(trans('cruds.mailingSetup.fields.mailing_operation_name')); ?></label>
        <select class="form-control <?php echo e($errors->has('mailing_operation_code') ? 'is-invalid' : ''); ?>" name="mailing_operation_code" id="mailing_operation_code_template" required onchange="GetMailTemplateByOperaionCode()">
            <option value disabled <?php echo e(old('mailing_operation_code', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
            <?php $__currentLoopData = App\Models\Member::MAILING_SETUP_OPERATION_CODE; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>" <?php echo e(old('mailing_operation_code', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php if($errors->has('mailing_operation_code')): ?>
            <div class="invalid-feedback">
                <?php echo e($errors->first('mailing_operation_code')); ?>

            </div>
        <?php endif; ?>
        <span class="help-block"><?php echo e(trans('cruds.mailingSetup.fields.mailing_operation_code')); ?></span>
    </div>
</div>
<div id="parameter" style="padding-bottom: 10px;">

</div>
<diV>
    <textarea class="ckeditor"  id="editor" name="template" style="height: 100%;">
    </textarea>
</diV>
<div style="height: 50px; padding-top: 20px;">
    <button class="btn btn-success pull-right" onclick="submitMailTemplate()" style="display: block;" id="btnSubmitTemplate">
        Submit
    </button>
</div>


<?php /**PATH /Users/kodekribtech/Documents/mycitadel/resources/views/admin/mailingSetup/mailing_template.blade.php ENDPATH**/ ?>