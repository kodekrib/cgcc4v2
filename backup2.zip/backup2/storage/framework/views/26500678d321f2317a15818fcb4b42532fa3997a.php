<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('join_department_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.join-departments.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.joinDepartment.title_singular')); ?>

            </a>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.joinDepartment.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">

        <ul class="nav nav-tabs" id="myTab">
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#membersList" role="tab"><?php echo e(trans('cruds.joinDepartment.title_singular')); ?> <?php echo e(trans('global.list')); ?></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#membersDelist" role="tab">Delisted Member</a>
                </li>

            </ul>

            <div class="tab-content" style="padding-top: 30px;">
                <div class="tab-pane active" id="membersList" role="tabpanel">
                    <table class=" table table-bordered table-striped table-hover datatable datatable-JoinDepartment">
                        <thead>
                            <tr>
                                <th width="10">

                                </th>
                                <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.id')); ?>

                                </th>

                                <th style="width: 150px">
                                    <?php echo e(trans('cruds.joinDepartment.fields.member_name')); ?>

                                </th>
                                <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.member_Email')); ?>

                                </th>
                                <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.member_phoneNumber')); ?>

                                </th>


                                <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.department')); ?>

                                </th>
                                <th>
                                    <?php echo e(trans('cruds.department.fields.department_email')); ?>

                                </th>
                                <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.member_type')); ?>

                                </th>
                                <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.primary_function')); ?>

                                </th>
                                <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.approval_status')); ?>

                                </th>
                                <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.delisted')); ?>

                                </th>

                                </th>
                                <!-- <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.reason')); ?>

                                </th> -->
                                <th>
                                    &nbsp;
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $joinDepartmentsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $joinDepartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-entry-id="<?php echo e($joinDepartment->id); ?>">
                                    <td>

                                    </td>
                                    <td>
                                        <?php echo e($joinDepartment->id ?? ''); ?>

                                    </td>


                                    <td style="width: 150px">
                                        <?php echo e($joinDepartment->created_by->member_name ?? ''); ?>

                                    </td>
                                    <td>
                                        <?php echo e($joinDepartment->created_by->email ?? ''); ?>

                                    </td>
                                    <td>
                                        <?php echo e($joinDepartment->created_by->mobile ?? ''); ?>

                                    </td>


                                    <td>
                                        <?php echo e($joinDepartment->department->department_name ?? ''); ?>

                                    </td>
                                    <td>
                                        <?php echo e($joinDepartment->department->department_email ?? ''); ?>

                                    </td>
                                    <td>
                                        <?php echo e(App\Models\JoinDepartment::MEMBER_TYPE_SELECT[$joinDepartment->member_type] ?? 'N/A'); ?>

                                    </td>
                                    <td>
                                        <?php echo e(App\Models\JoinDepartment::PRIMARY_FUNCTION_SELECT[$joinDepartment->primary_function] ?? ''); ?>

                                    </td>
                                    <td>
                                        <?php if($joinDepartment->approval_status == 0): ?>
                                            <a class="btn btn-xs btn-secondary" >
                                                Pending
                                            </a>
                                        <?php endif; ?>
                                        <?php if($joinDepartment->approval_status == 1): ?>
                                            <a class="btn btn-xs btn-danger" style="color: white;">
                                                Disapproved
                                            </a>
                                        <?php endif; ?>
                                        <?php if($joinDepartment->approval_status == 2): ?>
                                            <a class="btn btn-xs btn-success" style="color: white;">
                                            Approved
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($joinDepartment->status == 0): ?>
                                            <a class="btn btn-xs btn-danger" style="color: white;">
                                                Inactive
                                            </a>
                                        <?php endif; ?>
                                        <?php if($joinDepartment->status == 1): ?>
                                            <a class="btn btn-xs btn-success" style="color: white;">
                                            Active
                                            </a>
                                        <?php endif; ?>

                                    <!-- <td>
                                        <?php echo e($joinDepartment->reason ?? ''); ?>

                                    </td> -->
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('join_department_show')): ?>
                                            <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.join-departments.show', $joinDepartment->id)); ?>">
                                                <?php echo e(trans('global.view')); ?>

                                            </a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('join_department_edit')): ?>
                                            <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.join-departments.edit', $joinDepartment->id)); ?>">
                                                <?php echo e(trans('global.edit')); ?>

                                            </a>
                                        <?php endif; ?>

                                        <?php if($joinDepartment->status == 1): ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('join_department_edit')): ?>
                                                <a class="btn btn-xs btn-warning"   data-memberId="<?php echo e($joinDepartment->id); ?>" onclick="onShownDialog('<?php echo e($joinDepartment->id); ?>')">
                                                    Delist
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('join_department_delete')): ?>
                                            <form action="<?php echo e(route('admin.join-departments.destroy', $joinDepartment->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                                <input type="hidden" name="_method" value="DELETE">
                                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                            </form>
                                        <?php endif; ?>

                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="tab-pane " id="membersDelist" role="tabpanel">
                <table class=" table table-bordered table-striped table-hover datatable datatable-JoinDepartment">
                        <thead>
                            <tr>
                                <th width="10">

                                </th>
                                <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.id')); ?>

                                </th>

                                <th style="width: 150px">
                                    <?php echo e(trans('cruds.joinDepartment.fields.member_name')); ?>

                                </th>
                                <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.member_Email')); ?>

                                </th>
                                <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.member_phoneNumber')); ?>

                                </th>


                                <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.department')); ?>

                                </th>
                                <th>
                                    <?php echo e(trans('cruds.department.fields.department_email')); ?>

                                </th>
                                <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.member_type')); ?>

                                </th>
                                <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.primary_function')); ?>

                                </th>
                                <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.approval_status')); ?>

                                </th>
                                <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.delisted')); ?>

                                </th>

                                </th>
                                <!-- <th>
                                    <?php echo e(trans('cruds.joinDepartment.fields.reason')); ?>

                                </th> -->
                                <th>
                                    &nbsp;
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $joinDepartmentsDelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $joinDepartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-entry-id="<?php echo e($joinDepartment->id); ?>">
                                    <td>

                                    </td>
                                    <td>
                                        <?php echo e($joinDepartment->id ?? ''); ?>

                                    </td>


                                    <td style="width: 150px">
                                        <?php echo e($joinDepartment->created_by->member_name ?? ''); ?>

                                    </td>
                                    <td>
                                        <?php echo e($joinDepartment->created_by->email ?? ''); ?>

                                    </td>
                                    <td>
                                        <?php echo e($joinDepartment->created_by->mobile ?? ''); ?>

                                    </td>


                                    <td>
                                        <?php echo e($joinDepartment->department->department_name ?? ''); ?>

                                    </td>
                                    <td>
                                        <?php echo e($joinDepartment->department->department_email ?? ''); ?>

                                    </td>
                                    <td>
                                        <?php echo e(App\Models\JoinDepartment::MEMBER_TYPE_SELECT[$joinDepartment->member_type] ?? 'N/A'); ?>

                                    </td>
                                    <td>
                                        <?php echo e(App\Models\JoinDepartment::PRIMARY_FUNCTION_SELECT[$joinDepartment->primary_function] ?? ''); ?>

                                    </td>
                                    <td>
                                        <a class="btn btn-xs btn-danger" style="color: white;">
                                                Delist
                                        </a>
                                        </td>
                                    <td>
                                        <?php if($joinDepartment->status == 0): ?>
                                            <a class="btn btn-xs btn-danger" style="color: white;">
                                                Inactive
                                            </a>
                                        <?php endif; ?>
                                        <?php if($joinDepartment->status == 1): ?>
                                            <a class="btn btn-xs btn-success" style="color: white;">
                                            Active
                                            </a>
                                        <?php endif; ?>


                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('join_department_show')): ?>
                                            <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.join-departments.show', $joinDepartment->id)); ?>">
                                                <?php echo e(trans('global.view')); ?>

                                            </a>
                                        <?php endif; ?>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Member Delist</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <div class="form-group">
                <label for="reason"><?php echo e(trans('cruds.joinDepartment.fields.reason')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('reason') ? 'is-invalid' : ''); ?>" name="reason" id="reason"></textarea>
                <?php if($errors->has('reason')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('reason')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.joinDepartment.fields.reason_helper')); ?></span>
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" onclick="onDelistAMember()">Delist Member</button>
      </div>
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>

    var selectMemberTodDelist;


    function onDelistAMember(){
        const txt = $('#reason').val();
        AskQuestion('Do want to delist this department member').then(ask =>{
            if(ask){
                Post("<?php echo e(route('admin.join-departments.delist-member')); ?>", {id: selectMemberTodDelist, reason: txt}, true)
                .then(res => {
                    console.log(res);
                    selectMemberTodDelist = null;
                    $('#exampleModal').modal('hide');
                    window.location.reload();
                });
            }
        })

    }

    function onShownDialog(Id){
        $('#exampleModal').modal('show');
        selectMemberTodDelist =Id;
    }


    $('#exampleModal').on('show.bs.modal', function (event) {
        var button = event.relatedTarget;
        var Id = button.dataset['memberid'];
        selectMemberTodDelist =Id;

    });
    $(function () {
    let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('join_department_delete')): ?>
        let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
        let deleteButton = {
            text: deleteButtonTrans,
            url: "<?php echo e(route('admin.join-departments.massDestroy')); ?>",
            className: 'btn-danger',
            action: function (e, dt, node, config) {
            var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
                return $(entry).data('entry-id')
            });

            if (ids.length === 0) {
                alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

                return
            }

            if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
                $.ajax({
                headers: {'x-csrf-token': _token},
                method: 'POST',
                url: config.url,
                data: { ids: ids, _method: 'DELETE' }})
                .done(function () { location.reload() })
            }
            }
        }
        dtButtons.push(deleteButton)
    <?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 2, 'desc' ]],
    pageLength: 50,
  });
  let table = $('.datatable-JoinDepartment:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });

})

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kodekribtech/Documents/mycitadel/resources/views/admin/joinDepartments/index.blade.php ENDPATH**/ ?>