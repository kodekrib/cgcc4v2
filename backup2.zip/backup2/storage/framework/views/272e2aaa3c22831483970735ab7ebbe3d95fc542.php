<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.venue.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.venues.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="venue_name"><?php echo e(trans('cruds.venue.fields.venue_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('venue_name') ? 'is-invalid' : ''); ?>" type="text" name="venue_name" id="venue_name" value="<?php echo e(old('venue_name', '')); ?>" required>
                <?php if($errors->has('venue_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('venue_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.venue.fields.venue_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="venue_description"><?php echo e(trans('cruds.venue.fields.venue_description')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('venue_description') ? 'is-invalid' : ''); ?>" name="venue_description" id="venue_description"><?php echo e(old('venue_description')); ?></textarea>
                <?php if($errors->has('venue_description')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('venue_description')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.venue.fields.venue_description_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="accessories_equipments"><?php echo e(trans('cruds.venue.fields.accessories_equipment')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('accessories_equipments') ? 'is-invalid' : ''); ?>" name="accessories_equipments[]" id="accessories_equipments" multiple required>
                    <?php $__currentLoopData = $accessories_equipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $accessories_equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(in_array($id, old('accessories_equipments', [])) ? 'selected' : ''); ?>><?php echo e($accessories_equipment); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('accessories_equipments')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('accessories_equipments')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.venue.fields.accessories_equipment_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="accessibility_features"><?php echo e(trans('cruds.venue.fields.accessibility_features')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('accessibility_features') ? 'is-invalid' : ''); ?>" name="accessibility_features[]" id="accessibility_features" multiple>
                    <?php $__currentLoopData = $accessibility_features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $accessibility_feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(in_array($id, old('accessibility_features', [])) ? 'selected' : ''); ?>><?php echo e($accessibility_feature); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('accessibility_features')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('accessibility_features')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.venue.fields.accessibility_features_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="venue_capacity"><?php echo e(trans('cruds.venue.fields.venue_capacity')); ?></label>
                <input class="form-control <?php echo e($errors->has('venue_capacity') ? 'is-invalid' : ''); ?>" type="number" name="venue_capacity" id="venue_capacity" value="<?php echo e(old('venue_capacity', '')); ?>" step="1" required>
                <?php if($errors->has('venue_capacity')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('venue_capacity')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.venue.fields.venue_capacity_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="size"><?php echo e(trans('cruds.venue.fields.size')); ?></label>
                <input class="form-control <?php echo e($errors->has('size') ? 'is-invalid' : ''); ?>" type="number" name="size" id="size" value="<?php echo e(old('size', '')); ?>" step="1">
                <?php if($errors->has('size')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('size')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.venue.fields.size_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="venue_location_id"><?php echo e(trans('cruds.venue.fields.venue_location')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('venue_location') ? 'is-invalid' : ''); ?>" name="venue_location_id" id="venue_location_id" required>
                    <?php $__currentLoopData = $venue_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('venue_location_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('venue_location')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('venue_location')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.venue.fields.venue_location_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/venues/create.blade.php ENDPATH**/ ?>