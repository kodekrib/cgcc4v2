<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.bankAccountDetail.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.bank-account-details.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="account_name"><?php echo e(trans('cruds.bankAccountDetail.fields.account_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('account_name') ? 'is-invalid' : ''); ?>" type="text" name="account_name" id="account_name" value="<?php echo e(old('account_name', '')); ?>">
                <?php if($errors->has('account_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('account_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.bankAccountDetail.fields.account_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="account_type_id"><?php echo e(trans('cruds.bankAccountDetail.fields.account_type')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('account_type') ? 'is-invalid' : ''); ?>" name="account_type_id" id="account_type_id">
                    <?php $__currentLoopData = $account_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('account_type_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('account_type')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('account_type')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.bankAccountDetail.fields.account_type_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="currency_id"><?php echo e(trans('cruds.bankAccountDetail.fields.currency')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('currency') ? 'is-invalid' : ''); ?>" name="currency_id" id="currency_id">
                    <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('currency_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('currency')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('currency')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.bankAccountDetail.fields.currency_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="account_number"><?php echo e(trans('cruds.bankAccountDetail.fields.account_number')); ?></label>
                <input class="form-control <?php echo e($errors->has('account_number') ? 'is-invalid' : ''); ?>" type="text" name="account_number" id="account_number" value="<?php echo e(old('account_number', '')); ?>">
                <?php if($errors->has('account_number')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('account_number')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.bankAccountDetail.fields.account_number_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="sort_code"><?php echo e(trans('cruds.bankAccountDetail.fields.sort_code')); ?></label>
                <input class="form-control <?php echo e($errors->has('sort_code') ? 'is-invalid' : ''); ?>" type="text" name="sort_code" id="sort_code" value="<?php echo e(old('sort_code', '')); ?>">
                <?php if($errors->has('sort_code')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('sort_code')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.bankAccountDetail.fields.sort_code_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/bankAccountDetails/create.blade.php ENDPATH**/ ?>