<ul class="sidebar-nav" data-coreui="navigation" data-simplebar="">
        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.home')); ?>">
            <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-speedometer"></use>
            </svg> <?php echo e(trans('global.dashboard')); ?></a></li>
        
  		<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('church_affiliation_access')): ?>
        <li class="nav-group <?php echo e(request()->is("admin/ats-memberships*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/join-departments*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/members-affinity-groups*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/cihmembers*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/mfs*") ? "c-show" : ""); ?>"><a class="nav-link nav-group-toggle" href="#">
            <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-cursor"></use>
            </svg> <?php echo e(trans('cruds.churchAffiliation.title')); ?></a>
          <ul class="nav-group-items">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ats_membership_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/ats-memberships") || request()->is("admin/ats-memberships/*") ? "c-active" : ""); ?>" href="<?php echo e(route('admin.ats-memberships.index')); ?>"><span class="nav-icon"></span> <?php echo e(trans('cruds.atsMembership.title')); ?></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('join_department_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/join-departments") || request()->is("admin/join-departments/*") ? "c-active" : ""); ?>" href="<?php echo e(route('admin.join-departments.index')); ?>"> <?php echo e(trans('cruds.joinDepartment.title')); ?></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('members_affinity_group_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/members-affinity-groups") || request()->is("admin/members-affinity-groups/*") ? "c-active" : ""); ?>" href="<?php echo e(route('admin.members-affinity-groups.index')); ?>"> <?php echo e(trans('cruds.membersAffinityGroup.title')); ?></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cihmember_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/cihmembers") || request()->is("admin/cihmembers/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.cihmembers.index")); ?>"> <?php echo e(trans('cruds.cihmember.title')); ?></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mf_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/mfs") || request()->is("admin/mfs/*") ? "c-active" : ""); ?>" href="<?php echo e(route('admin.mfs.index')); ?>"><span class="nav-icon"></span> <?php echo e(trans('cruds.mf.title')); ?></a></li>
            <?php endif; ?>
          </ul>
        </li>
  		<?php endif; ?>
  		<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('appointment_management_access')): ?>
  		<li class="nav-group <?php echo e(request()->is("admin/appointment-bookings*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/type-of-appoinments*") ? "c-show" : ""); ?>"><a class="nav-link nav-group-toggle" href="#">
            <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-notes"></use>
            </svg> <?php echo e(trans('cruds.appointmentManagement.title')); ?></a>
          <ul class="nav-group-items">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('appointment_booking_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/appointment-bookings") || request()->is("admin/appointment-bookings/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.appointment-bookings.index")); ?>"> <?php echo e(trans('cruds.appointmentBooking.title')); ?></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('type_of_appoinment_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/type-of-appoinments") || request()->is("admin/type-of-appoinments/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.type-of-appoinments.index")); ?>"> <?php echo e(trans('cruds.typeOfAppoinment.title')); ?></a></li>
            <?php endif; ?>
          </ul>
        </li>           
        <?php endif; ?>
  		<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('meeting_management_access')): ?>
  		<li class="nav-group <?php echo e(request()->is("admin/meetings*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/attendance-managements*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/meeting-types*") ? "c-show" : ""); ?>"><a class="nav-link nav-group-toggle" href="#">
            <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-star"></use>
            </svg> <?php echo e(trans('cruds.meetingManagement.title')); ?></a>
          <ul class="nav-group-items">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('meeting_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/meetings") || request()->is("admin/meetings/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.meetings.index")); ?>"> <?php echo e(trans('cruds.meeting.title')); ?></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attendance_management_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/attendance-managements") || request()->is("admin/attendance-managements/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.attendance-managements.index")); ?>"> <?php echo e(trans('cruds.attendanceManagement.title')); ?></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('meeting_type_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/meeting-types") || request()->is("admin/meeting-types/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.meeting-types.index")); ?>"><?php echo e(trans('cruds.meetingType.title')); ?></a></li>
            <?php endif; ?>
          </ul>
        </li>
        <?php endif; ?>
  		<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('venue_management_access')): ?>
  		<li class="nav-group <?php echo e(request()->is("admin/bookings*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/venues*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/venue-accessories*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/accessibility-features*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/locations*") ? "c-show" : ""); ?>">
          <a class="nav-link nav-group-toggle" href="#">
            <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-bell"></use>
            </svg> <?php echo e(trans('cruds.venueManagement.title')); ?></a>
            <ul class="nav-group-items">
              	<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('booking_access')): ?>
              	<li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/bookings") || request()->is("admin/bookings/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.bookings.index")); ?>"> <?php echo e(trans('cruds.booking.title')); ?></a></li>
            	<?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('venue_access')): ?>
              	<li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/venues") || request()->is("admin/venues/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.venues.index")); ?>"> <?php echo e(trans('cruds.venue.title')); ?></a></li>
            	<?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('venue_accessory_access')): ?>
              	<li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/venue-accessories") || request()->is("admin/venue-accessories/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.venue-accessories.index")); ?>"> <?php echo e(trans('cruds.venueAccessory.title')); ?></a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accessibility_feature_access')): ?>
              	<li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/accessibility-features") || request()->is("admin/accessibility-features/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.accessibility-features.index")); ?>"> <?php echo e(trans('cruds.accessibilityFeature.title')); ?></a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('location_access')): ?>
              	<li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/locations") || request()->is("admin/locations/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.locations.index")); ?>"> <?php echo e(trans('cruds.location.title')); ?></a></li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>
       	<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('event_church_program_access')): ?>
  		<li class="nav-group <?php echo e(request()->is("admin/events*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/event-types*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/attendees*") ? "c-show" : ""); ?>"><a class="nav-link nav-group-toggle" href="#">
            <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-star"></use>
            </svg> <?php echo e(trans('cruds.eventChurchProgram.title')); ?></a>
          <ul class="nav-group-items">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('event_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/events") || request()->is("admin/events/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.events.index")); ?>"> <?php echo e(trans('cruds.event.title')); ?></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('event_type_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/event-types") || request()->is("admin/event-types/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.event-types.index")); ?>"> <?php echo e(trans('cruds.eventType.title')); ?></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attendee_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/attendees") || request()->is("admin/attendees/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.attendees.index")); ?>"> <?php echo e(trans('cruds.attendee.title')); ?></a></li>
          	<?php endif; ?>
          </ul>
        </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('issue_management_access')): ?>
  		<li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/issue-managements") || request()->is("admin/issue-managements/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.issue-managements.index")); ?>">
            <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-calculator"></use>
            </svg> <?php echo e(trans('cruds.issueManagement.title')); ?></a>
  		</li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('goal_access')): ?>
  		<li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/goals") || request()->is("admin/goals/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.goals.index")); ?>">
            <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-calculator"></use>
            </svg> <?php echo e(trans('cruds.goal.title')); ?></a>
  		</li>
        <?php endif; ?>
  		<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('notification_management_access')): ?>
  		<li class="nav-group <?php echo e(request()->is("admin/notifications*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/reminders*") ? "c-show" : ""); ?>"><a class="nav-link nav-group-toggle" href="#">
            <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-bell"></use>
            </svg> <?php echo e(trans('cruds.notificationManagement.title')); ?></a>
          <ul class="nav-group-items">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('notification_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/notifications") || request()->is("admin/notifications/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.notifications.index")); ?>"> <?php echo e(trans('cruds.notification.title')); ?></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reminder_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/reminders") || request()->is("admin/reminders/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.reminders.index")); ?>"> <?php echo e(trans('cruds.reminder.title')); ?></a></li>
            <?php endif; ?>
            <li class="nav-item"><a class="nav-link" href="notifications/modals.html"><span class="nav-icon"></span> Modals</a></li>
            <li class="nav-item"><a class="nav-link" href="notifications/toasts.html"><span class="nav-icon"></span> Toasts</a></li>
          </ul>
        </li>
        <?php endif; ?>        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('outreach_and_mission_access')): ?>
  		<li class="nav-group<?php echo e(request()->is("admin/outreaches*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/outreach-types*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/e-flyers*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/outreaches*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/outreach-types*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/e-flyers*") ? "c-show" : ""); ?>" ><a class="nav-link nav-group-toggle" href="#">
            <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-bell"></use>
            </svg> <?php echo e(trans('cruds.outreachAndMission.title')); ?></a>
          <ul class="nav-group-items">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('outreach_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/outreaches") || request()->is("admin/outreaches/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.outreaches.index")); ?>"> <?php echo e(trans('cruds.outreach.title')); ?></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('outreach_type_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/outreach-types") || request()->is("admin/outreach-types/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.outreach-types.index")); ?>"> <?php echo e(trans('cruds.outreachType.title')); ?></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('e_flyer_access')): ?>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is("admin/e-flyers") || request()->is("admin/e-flyers/*") ? "c-active" : ""); ?>" href="<?php echo e(route("admin.e-flyers.index")); ?>"> <?php echo e(trans('cruds.eFlyer.title')); ?></a></li>
            <?php endif; ?>
           </ul>
        </li>
        <?php endif; ?>      
         
  
  
 		<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ancillary_service_access')): ?>
            <li class="nav-group <?php echo e(request()->is("admin/ancillary-managements*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/service-types*") ? "c-show" : ""); ?>">
                <a class="nav-link nav-group-toggle" href="#">
                    <svg class="nav-icon">
                        <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-bell"></use>
                </svg> <?php echo e(trans('cruds.ancillaryService.title')); ?></a>
                <ul class="nav-group-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ancillary_management_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.ancillary-managements.index")); ?>" class="nav-link <?php echo e(request()->is("admin/ancillary-managements") || request()->is("admin/ancillary-managements/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.ancillaryManagement.title')); ?></a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service_type_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.service-types.index")); ?>" class="nav-link <?php echo e(request()->is("admin/service-types") || request()->is("admin/service-types/*") ? "c-active" : ""); ?>"><?php echo e(trans('cruds.serviceType.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('chat_management_access')): ?>
            <li class="nav-item">
                <a href="<?php echo e(route("admin.chat-managements.index")); ?>" class="nav-link <?php echo e(request()->is("admin/chat-managements") || request()->is("admin/chat-managements/*") ? "c-active" : ""); ?>">
                    <svg class="nav-icon">
                        <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-bell"></use>
                </svg>
                    <?php echo e(trans('cruds.chatManagement.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
            <li class="nav-group <?php echo e(request()->is("admin/permissions*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/audit-logs*") ? "c-show" : ""); ?>">
                <a class="nav-link nav-group-toggle" href="#">
                    <svg class="nav-icon">
                        <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-bell"></use>
                </svg>
                    <?php echo e(trans('cruds.userManagement.title')); ?>

                </a>
                <ul class="nav-group-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.permissions.index")); ?>" class="nav-link <?php echo e(request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.permission.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.roles.index")); ?>" class="nav-link <?php echo e(request()->is("admin/roles") || request()->is("admin/roles/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.role.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('audit_log_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.audit-logs.index")); ?>" class="nav-link <?php echo e(request()->is("admin/audit-logs") || request()->is("admin/audit-logs/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.auditLog.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asset_management_access')): ?>
            <li class="nav-group <?php echo e(request()->is("admin/asset-categories*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/asset-locations*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/asset-statuses*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/assets*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/assets-histories*") ? "c-show" : ""); ?>">
                <a class="nav-link nav-group-toggle" href="#">
                    <svg class="nav-icon">
                        <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-bell"></use>
                </svg> <?php echo e(trans('cruds.assetManagement.title')); ?>

                </a>
                <ul class="nav-group-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asset_category_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.asset-categories.index")); ?>" class="nav-link <?php echo e(request()->is("admin/asset-categories") || request()->is("admin/asset-categories/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-tags c-sidebar-nav-icon"> <?php echo e(trans('cruds.assetCategory.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asset_location_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.asset-locations.index")); ?>" class="nav-link <?php echo e(request()->is("admin/asset-locations") || request()->is("admin/asset-locations/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-map-marker c-sidebar-nav-icon"> <?php echo e(trans('cruds.assetLocation.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asset_status_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.asset-statuses.index")); ?>" class="nav-link <?php echo e(request()->is("admin/asset-statuses") || request()->is("admin/asset-statuses/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.assetStatus.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asset_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.assets.index")); ?>" class="nav-link <?php echo e(request()->is("admin/assets") || request()->is("admin/assets/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.asset.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assets_history_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.assets-histories.index")); ?>" class="nav-link <?php echo e(request()->is("admin/assets-histories") || request()->is("admin/assets-histories/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.assetsHistory.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cih_management_access')): ?>
            <li class="nav-group <?php echo e(request()->is("admin/first-timers*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/dedications*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/christenings*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/cih-requests*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/cihzones*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/centres*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/cih-types-of-requests*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/cih-centers-inspections*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/inspectorate-groups*") ? "c-show" : ""); ?>">
                <a class="nav-link nav-group-toggle" href="#">
                    <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-bell"></use>
            </svg>
                    <?php echo e(trans('cruds.cihManagement.title')); ?>

                </a>
                <ul class="nav-group-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('first_timer_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.first-timers.index")); ?>" class="nav-link <?php echo e(request()->is("admin/first-timers") || request()->is("admin/first-timers/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.firstTimer.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dedication_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.dedications.index")); ?>" class="nav-link <?php echo e(request()->is("admin/dedications") || request()->is("admin/dedications/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.dedication.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('christening_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.christenings.index")); ?>" class="nav-link <?php echo e(request()->is("admin/christenings") || request()->is("admin/christenings/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.christening.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cih_request_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.cih-requests.index")); ?>" class="nav-link <?php echo e(request()->is("admin/cih-requests") || request()->is("admin/cih-requests/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.cihRequest.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cihzone_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.cihzones.index")); ?>" class="nav-link <?php echo e(request()->is("admin/cihzones") || request()->is("admin/cihzones/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.cihzone.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('centre_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.centres.index")); ?>" class="nav-link <?php echo e(request()->is("admin/centres") || request()->is("admin/centres/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.centre.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cih_types_of_request_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.cih-types-of-requests.index")); ?>" class="nav-link <?php echo e(request()->is("admin/cih-types-of-requests") || request()->is("admin/cih-types-of-requests/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw far fa-envelope c-sidebar-nav-icon"> <?php echo e(trans('cruds.cihTypesOfRequest.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cih_centers_inspection_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.cih-centers-inspections.index")); ?>" class="nav-link <?php echo e(request()->is("admin/cih-centers-inspections") || request()->is("admin/cih-centers-inspections/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.cihCentersInspection.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inspectorate_group_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.inspectorate-groups.index")); ?>" class="nav-link <?php echo e(request()->is("admin/inspectorate-groups") || request()->is("admin/inspectorate-groups/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.inspectorateGroup.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('join_empowerment_access')): ?>
            <li class="nav-group <?php echo e(request()->is("admin/empowerments*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/mailings*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/area-of-specializations*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/job-levels*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/empowerment-training-needs*") ? "c-show" : ""); ?>">
                <a class="nav-link nav-group-toggle" href="#">
                  <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-bell"></use>
            </svg>
            <?php echo e(trans('cruds.joinEmpowerment.title')); ?>

                </a>
                <ul class="nav-group-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('empowerment_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.empowerments.index")); ?>" class="nav-link <?php echo e(request()->is("admin/empowerments") || request()->is("admin/empowerments/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.empowerment.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mailing_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.mailings.index")); ?>" class="nav-link <?php echo e(request()->is("admin/mailings") || request()->is("admin/mailings/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.mailing.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('area_of_specialization_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.area-of-specializations.index")); ?>" class="nav-link <?php echo e(request()->is("admin/area-of-specializations") || request()->is("admin/area-of-specializations/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.areaOfSpecialization.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('job_level_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.job-levels.index")); ?>" class="nav-link <?php echo e(request()->is("admin/job-levels") || request()->is("admin/job-levels/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.jobLevel.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('empowerment_training_need_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.empowerment-training-needs.index")); ?>" class="nav-link <?php echo e(request()->is("admin/empowerment-training-needs") || request()->is("admin/empowerment-training-needs/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.empowermentTrainingNeed.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment_access')): ?>
            <li class="nav-item">
                <a href="<?php echo e(route("admin.payments.index")); ?>" class="nav-link <?php echo e(request()->is("admin/payments") || request()->is("admin/payments/*") ? "c-active" : ""); ?>">
                  <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-bell"></use>
            </svg> <?php echo e(trans('cruds.payment.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_management_access')): ?>
            <li class="nav-group <?php echo e(request()->is("admin/task-statuses*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/task-tags*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/tasks*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/tasks-calendars*") ? "c-show" : ""); ?>">
                <a class="nav-link nav-group-toggle" href="#">
                    <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-calculator"></use>
            </svg>
                    <?php echo e(trans('cruds.taskManagement.title')); ?>

                </a>
                <ul class="nav-group-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_status_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.task-statuses.index")); ?>" class="nav-link <?php echo e(request()->is("admin/task-statuses") || request()->is("admin/task-statuses/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.taskStatus.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_tag_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.task-tags.index")); ?>" class="nav-link <?php echo e(request()->is("admin/task-tags") || request()->is("admin/task-tags/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.taskTag.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.tasks.index")); ?>" class="nav-link <?php echo e(request()->is("admin/tasks") || request()->is("admin/tasks/*") ? "c-active" : ""); ?>">
                                <?php echo e(trans('cruds.task.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tasks_calendar_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.tasks-calendars.index")); ?>" class="nav-link <?php echo e(request()->is("admin/tasks-calendars") || request()->is("admin/tasks-calendars/*") ? "c-active" : ""); ?>"> 
                                <?php echo e(trans('cruds.tasksCalendar.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment_setting_access')): ?>
            <li class="nav-group <?php echo e(request()->is("admin/bank-account-details*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/bank-account-types*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/currencies*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/flutterwave-apikeys*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/cgcc-payment-forms*") ? "c-show" : ""); ?>">
                <a class="nav-link nav-group-toggle" href="#">
                    <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-calculator"></use>
            </svg> <?php echo e(trans('cruds.paymentSetting.title')); ?>

                </a>
                <ul class="nav-group-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bank_account_detail_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.bank-account-details.index")); ?>" class="nav-link <?php echo e(request()->is("admin/bank-account-details") || request()->is("admin/bank-account-details/*") ? "c-active" : ""); ?>"> 
                                <?php echo e(trans('cruds.bankAccountDetail.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bank_account_type_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.bank-account-types.index")); ?>" class="nav-link <?php echo e(request()->is("admin/bank-account-types") || request()->is("admin/bank-account-types/*") ? "c-active" : ""); ?>"> 
                                <?php echo e(trans('cruds.bankAccountType.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('currency_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.currencies.index")); ?>" class="nav-link <?php echo e(request()->is("admin/currencies") || request()->is("admin/currencies/*") ? "c-active" : ""); ?>"> 
                                <?php echo e(trans('cruds.currency.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('flutterwave_apikey_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.flutterwave-apikeys.index")); ?>" class="nav-link <?php echo e(request()->is("admin/flutterwave-apikeys") || request()->is("admin/flutterwave-apikeys/*") ? "c-active" : ""); ?>"> 
                                <?php echo e(trans('cruds.flutterwaveApikey.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cgcc_payment_form_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.cgcc-payment-forms.index")); ?>" class="nav-link <?php echo e(request()->is("admin/cgcc-payment-forms") || request()->is("admin/cgcc-payment-forms/*") ? "c-active" : ""); ?>"> 
                                <?php echo e(trans('cruds.cgccPaymentForm.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('faq_management_access')): ?>
            <li class="nav-group <?php echo e(request()->is("admin/faq-categories*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/faq-questions*") ? "c-show" : ""); ?>">
                <a class="nav-link nav-group-toggle" href="#">
                    <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-calculator"></use>
            </svg>
                    <?php echo e(trans('cruds.faqManagement.title')); ?>

                </a>
                <ul class="nav-group-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('faq_category_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.faq-categories.index")); ?>" class="nav-link <?php echo e(request()->is("admin/faq-categories") || request()->is("admin/faq-categories/*") ? "c-active" : ""); ?>"> 
                                <?php echo e(trans('cruds.faqCategory.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('faq_question_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.faq-questions.index")); ?>" class="nav-link <?php echo e(request()->is("admin/faq-questions") || request()->is("admin/faq-questions/*") ? "c-active" : ""); ?>"> 
                                <?php echo e(trans('cruds.faqQuestion.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('administrative_role_access')): ?>
            <li class="nav-group <?php echo e(request()->is("admin/users*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/affinity-groups*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/ats-membership-records*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/departments*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/mountains-of-influences*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/missionary-forces*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/user-alerts*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/*") ? "c-show" : ""); ?>">
                <a class="nav-link nav-group-toggle" href="#">
                    <svg class="nav-icon">
                        <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-calculator"></use>
                    </svg>
                    <?php echo e(trans('cruds.administrativeRole.title')); ?>

                </a>
                <ul class="nav-group-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.users.index")); ?>" class="nav-link <?php echo e(request()->is("admin/users") || request()->is("admin/users/*") ? "c-active" : ""); ?>">
                                <?php echo e(trans('cruds.user.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('affinity_group_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.affinity-groups.index")); ?>" class="nav-link <?php echo e(request()->is("admin/affinity-groups") || request()->is("admin/affinity-groups/*") ? "c-active" : ""); ?>">
                                 <?php echo e(trans('cruds.affinityGroup.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ats_membership_record_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.ats-membership-records.index")); ?>" class="nav-link <?php echo e(request()->is("admin/ats-membership-records") || request()->is("admin/ats-membership-records/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.atsMembershipRecord.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('department_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.departments.index")); ?>" class="nav-link <?php echo e(request()->is("admin/departments") || request()->is("admin/departments/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.department.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mountains_of_influence_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.mountains-of-influences.index")); ?>" class="nav-link <?php echo e(request()->is("admin/mountains-of-influences") || request()->is("admin/mountains-of-influences/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.mountainsOfInfluence.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('missionary_force_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.missionary-forces.index")); ?>" class="nav-link <?php echo e(request()->is("admin/missionary-forces") || request()->is("admin/missionary-forces/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.missionaryForce.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_alert_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.user-alerts.index")); ?>" class="nav-link <?php echo e(request()->is("admin/user-alerts") || request()->is("admin/user-alerts/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.userAlert.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('misc_access')): ?>
                        <li class="nav-group <?php echo e(request()->is("admin/titles*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/marital-statuses*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/employment-statuses*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/qualification-settings*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/industry-sectors*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/sub-sectors*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/organization-types*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/sports*") ? "c-show" : ""); ?>">
                            <a class="nav-link nav-group-toggle" href="#">
                                <svg class="nav-icon">
                                <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-calculator"></use>
                                </svg>
                                <?php echo e(trans('cruds.misc.title')); ?>

                            </a>
                            <ul class="nav-group-items">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('title_access')): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route("admin.titles.index")); ?>" class="nav-link <?php echo e(request()->is("admin/titles") || request()->is("admin/titles/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.title.title')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('marital_status_access')): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route("admin.marital-statuses.index")); ?>" class="nav-link <?php echo e(request()->is("admin/marital-statuses") || request()->is("admin/marital-statuses/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.maritalStatus.title')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employment_status_access')): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route("admin.employment-statuses.index")); ?>" class="nav-link <?php echo e(request()->is("admin/employment-statuses") || request()->is("admin/employment-statuses/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.employmentStatus.title')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('qualification_setting_access')): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route("admin.qualification-settings.index")); ?>" class="nav-link <?php echo e(request()->is("admin/qualification-settings") || request()->is("admin/qualification-settings/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.qualificationSetting.title')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('industry_sector_access')): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route("admin.industry-sectors.index")); ?>" class="nav-link <?php echo e(request()->is("admin/industry-sectors") || request()->is("admin/industry-sectors/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.industrySector.title')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sub_sector_access')): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route("admin.sub-sectors.index")); ?>" class="nav-link <?php echo e(request()->is("admin/sub-sectors") || request()->is("admin/sub-sectors/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.subSector.title')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('organization_type_access')): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route("admin.organization-types.index")); ?>" class="nav-link <?php echo e(request()->is("admin/organization-types") || request()->is("admin/organization-types/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.organizationType.title')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sport_access')): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route("admin.sports.index")); ?>" class="nav-link <?php echo e(request()->is("admin/sports") || request()->is("admin/sports/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.sport.title')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sport_access')): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route("admin.mailingSetup.index")); ?>" class="nav-link <?php echo e(request()->is("admin/mailingSetup/create") || request()->is("admin/mailingSetup/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.mailingSetup.title')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('content_management_access')): ?>
            <li class="nav-group <?php echo e(request()->is("admin/content-categories*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/content-tags*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/content-pages*") ? "c-show" : ""); ?>">
                <a class="nav-link nav-group-toggle" href="#">
                    <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-bell"></use>
            </svg>
                    <?php echo e(trans('cruds.contentManagement.title')); ?>

                </a>
                <ul class="nav-group-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('content_category_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.content-categories.index")); ?>" class="nav-link <?php echo e(request()->is("admin/content-categories") || request()->is("admin/content-categories/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-folder c-sidebar-nav-icon"> 
                                <?php echo e(trans('cruds.contentCategory.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('content_tag_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.content-tags.index")); ?>" class="nav-link <?php echo e(request()->is("admin/content-tags") || request()->is("admin/content-tags/*") ? "c-active" : ""); ?>"> 
                                <?php echo e(trans('cruds.contentTag.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('content_page_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.content-pages.index")); ?>" class="nav-link <?php echo e(request()->is("admin/content-pages") || request()->is("admin/content-pages/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-file c-sidebar-nav-icon"> <?php echo e(trans('cruds.contentPage.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('contact_management_access')): ?>
            <li class="nav-group <?php echo e(request()->is("admin/contact-companies*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/contact-contacts*") ? "c-show" : ""); ?>">
                <a class="nav-link nav-group-toggle" href="#">
                    <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-bell"></use>
            </svg>
                    <?php echo e(trans('cruds.contactManagement.title')); ?>

                </a>
                <ul class="nav-group-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('contact_company_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.contact-companies.index")); ?>" class="nav-link <?php echo e(request()->is("admin/contact-companies") || request()->is("admin/contact-companies/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-building c-sidebar-nav-icon"> <?php echo e(trans('cruds.contactCompany.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('contact_contact_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.contact-contacts.index")); ?>" class="nav-link <?php echo e(request()->is("admin/contact-contacts") || request()->is("admin/contact-contacts/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.contactContact.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('at_access')): ?>
            <li class="nav-group <?php echo e(request()->is("admin/courses*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/lessons*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/tests*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/questions*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/question-options*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/test-results*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/test-answers*") ? "c-show" : ""); ?>">
                <a class="nav-link nav-group-toggle" href="#">
                    <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-bell"></use>
            </svg>
                    <?php echo e(trans('cruds.at.title')); ?>

                </a>
                <ul class="nav-group-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('course_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.courses.index")); ?>" class="nav-link <?php echo e(request()->is("admin/courses") || request()->is("admin/courses/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.course.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lesson_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.lessons.index")); ?>" class="nav-link <?php echo e(request()->is("admin/lessons") || request()->is("admin/lessons/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.lesson.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('test_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.tests.index")); ?>" class="nav-link <?php echo e(request()->is("admin/tests") || request()->is("admin/tests/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.test.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('question_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.questions.index")); ?>" class="nav-link <?php echo e(request()->is("admin/questions") || request()->is("admin/questions/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.question.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('question_option_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.question-options.index")); ?>" class="nav-link <?php echo e(request()->is("admin/question-options") || request()->is("admin/question-options/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.questionOption.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('test_result_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.test-results.index")); ?>" class="nav-link <?php echo e(request()->is("admin/test-results") || request()->is("admin/test-results/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.testResult.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('test_answer_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.test-answers.index")); ?>" class="nav-link <?php echo e(request()->is("admin/test-answers") || request()->is("admin/test-answers/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.testAnswer.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_management_access')): ?>
            <li class="nav-group <?php echo e(request()->is("admin/product-categories*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/product-tags*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/products*") ? "c-show" : ""); ?>">
                <a class="nav-link nav-group-toggle" href="#">
                    <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-bell"></use>
            </svg>
                    <?php echo e(trans('cruds.productManagement.title')); ?>

                </a>
                <ul class="nav-group-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_category_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.product-categories.index")); ?>" class="nav-link <?php echo e(request()->is("admin/product-categories") || request()->is("admin/product-categories/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.productCategory.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_tag_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.product-tags.index")); ?>" class="nav-link <?php echo e(request()->is("admin/product-tags") || request()->is("admin/product-tags/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.productTag.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_access')): ?>
                        <li class="nav-item"><a href="<?php echo e(route("admin.products.index")); ?>" class="nav-link <?php echo e(request()->is("admin/products") || request()->is("admin/products/*") ? "c-active" : ""); ?>"> <?php echo e(trans('cruds.product.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
  		 <li class="nav-item">
            <a href="<?php echo e(route("admin.systemCalendar")); ?>" class="nav-link <?php echo e(request()->is("admin/system-calendar") || request()->is("admin/system-calendar/*") ? "c-active" : ""); ?>">
                <svg class="nav-icon">
              <use xlink:href="coreui/vendors/@coreui/icons/svg/free.svg#cil-bell"></use>
            </svg>
                <?php echo e(trans('global.systemCalendar')); ?>

            </a>
        </li>
  </ul>
   <?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/partials/menu.blade.php ENDPATH**/ ?>