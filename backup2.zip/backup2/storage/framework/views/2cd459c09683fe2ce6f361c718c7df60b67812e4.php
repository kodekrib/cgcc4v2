<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.appointmentBooking.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.appointment-bookings.update", [$appointmentBooking->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="member_name"><?php echo e(trans('cruds.appointmentBooking.fields.member_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('member_name') ? 'is-invalid' : ''); ?>" type="text" name="member_name" id="member_name" value="<?php echo e(old('member_name', $appointmentBooking->member_name)); ?>">
                <?php if($errors->has('member_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('member_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.appointmentBooking.fields.member_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="appointment_type_id"><?php echo e(trans('cruds.appointmentBooking.fields.appointment_type')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('appointment_type') ? 'is-invalid' : ''); ?>" name="appointment_type_id" id="appointment_type_id" disabled>
                    <?php $__currentLoopData = $appointment_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('appointment_type_id') ? old('appointment_type_id') : $appointmentBooking->appointment_type->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('appointment_type')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('appointment_type')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.appointmentBooking.fields.appointment_type_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="appointment_date"><?php echo e(trans('cruds.appointmentBooking.fields.appointment_date')); ?></label>
                <input class="form-control date <?php echo e($errors->has('appointment_date') ? 'is-invalid' : ''); ?>" type="text" name="appointment_date" id="appointment_date" value="<?php echo e(old('appointment_date', $appointmentBooking->appointment_date)); ?>" required>
                <?php if($errors->has('appointment_date')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('appointment_date')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.appointmentBooking.fields.appointment_date_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="appointment_time"><?php echo e(trans('cruds.appointmentBooking.fields.appointment_time')); ?></label>
                <input class="form-control timepicker <?php echo e($errors->has('appointment_time') ? 'is-invalid' : ''); ?>" type="text" name="appointment_time" id="appointment_time" value="<?php echo e(old('appointment_time', $appointmentBooking->appointment_time)); ?>" required>
                <?php if($errors->has('appointment_time')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('appointment_time')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.appointmentBooking.fields.appointment_time_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="purpose"><?php echo e(trans('cruds.appointmentBooking.fields.purpose')); ?></label>
                <textarea class="form-control ckeditor <?php echo e($errors->has('purpose') ? 'is-invalid' : ''); ?>" name="purpose" id="purpose"><?php echo old('purpose', $appointmentBooking->purpose); ?></textarea>
                <?php if($errors->has('purpose')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('purpose')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.appointmentBooking.fields.purpose_helper')); ?></span>
            </div>

            <div class="form-group">
                    <label><?php echo e(trans('cruds.joinDepartment.fields.approval_status')); ?></label>
                    <select class="form-control <?php echo e($errors->has('approved_status') ? 'is-invalid' : ''); ?>" name="approved_status" id="approved_status">
                        <option value disabled <?php echo e(old('approved_status', $appointmentBooking->approved_status) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                        <?php $__currentLoopData = App\Models\AppointmentBooking::APPROVAL_STATUS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option value="<?php echo e($key); ?>" <?php echo e(old('approved_status', $appointmentBooking->approved_status) === (integer) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('approved_status')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('approved_status')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.joinDepartment.fields.primary_function_helper')); ?></span>
            </div>
            <!-- <div class="form-group">
                <div class="form-check <?php echo e($errors->has('approved') ? 'is-invalid' : ''); ?>">
                    <input type="hidden" name="approved" value="0">
                    <input class="form-check-input" type="checkbox" name="approved" id="approved" value="1" <?php echo e($appointmentBooking->approved || old('approved', 0) === 1 ? 'checked' : ''); ?> onchange="ApprovalCheck('approved')">
                    <label class="form-check-label" for="approved"><?php echo e(trans('cruds.appointmentBooking.fields.approved')); ?></label>
                </div>
                <?php if($errors->has('approved')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('approved')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.appointmentBooking.fields.approved_helper')); ?></span>
            </div>
            <div class="form-group">
                <div class="form-check <?php echo e($errors->has('disapproved') ? 'is-invalid' : ''); ?>">
                    <input type="hidden" name="disapproved" value="0">
                    <input class="form-check-input" type="checkbox" name="disapproved" id="disapproved" value="1" <?php echo e($appointmentBooking->disapproved || old('disapproved', 0) === 1 ? 'checked' : ''); ?> onchange="ApprovalCheck('disapproved')">
                    <label class="form-check-label" for="disapproved"><?php echo e(trans('cruds.appointmentBooking.fields.disapproved')); ?></label>
                </div>
                <?php if($errors->has('disapproved')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('disapproved')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.appointmentBooking.fields.disapproved_helper')); ?></span>
            </div>
            <div class="form-group">
                <div class="form-check <?php echo e($errors->has('opened') ? 'is-invalid' : ''); ?>">
                    <input type="hidden" name="opened" value="0">
                    <input class="form-check-input" type="checkbox" name="opened" id="opened" value="1" <?php echo e($appointmentBooking->opened || old('opened', 0) === 1 ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="opened"><?php echo e(trans('cruds.appointmentBooking.fields.opened')); ?></label>
                </div>
                <?php if($errors->has('opened')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('opened')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.appointmentBooking.fields.opened_helper')); ?></span>
            </div> -->
            <div class="form-group">
                <div class="form-check <?php echo e($errors->has('re_assigned') ? 'is-invalid' : ''); ?>">
                    <input type="hidden" name="re_assigned" value="0">
                    <input class="form-check-input" type="checkbox" name="re_assigned" id="re_assigned" value="1" <?php echo e($appointmentBooking->re_assigned || old('re_assigned', 0) === 1 ? 'checked' : ''); ?> onchange='reassign()'>
                    <label class="form-check-label" for="re_assigned"><?php echo e(trans('cruds.appointmentBooking.fields.re_assigned')); ?></label>
                </div>
                <?php if($errors->has('re_assigned')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('re_assigned')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.appointmentBooking.fields.re_assigned_helper')); ?></span>
            </div>
            <div class="form-group" id="container_assigned_to">
                <label for="assigned_to_id"><?php echo e(trans('cruds.appointmentBooking.fields.assigned_to')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('assigned_to') ? 'is-invalid' : ''); ?>" name="assigned_to_id" id="assigned_to_id">
                    <?php $__currentLoopData = $assigned_tos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($entry->id); ?>" <?php echo e((old('assigned_to_id') ? old('assigned_to_id') : $appointmentBooking->assigned_to->id ?? '') == $entry->id ? 'selected' : ''); ?>><?php echo e($entry->member_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('assigned_to')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('assigned_to')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.appointmentBooking.fields.assigned_to_helper')); ?></span>
            </div>
            <!-- <div class="form-group">
                <div class="form-check <?php echo e($errors->has('in_progress') ? 'is-invalid' : ''); ?>">
                    <input type="hidden" name="in_progress" value="0">
                    <input class="form-check-input" type="checkbox" name="in_progress" id="in_progress" value="1" <?php echo e($appointmentBooking->in_progress || old('in_progress', 0) === 1 ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="in_progress"><?php echo e(trans('cruds.appointmentBooking.fields.in_progress')); ?></label>
                </div>
                <?php if($errors->has('in_progress')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('in_progress')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.appointmentBooking.fields.in_progress_helper')); ?></span>
            </div> -->
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function reassign(){
        if(document.getElementById('re_assigned').checked == true){
            document.getElementById('container_assigned_to').style.display ='block';
            $('[name=re_assigned]').val(1);
        } else {
            document.getElementById('container_assigned_to').style.display ='none';
            $('[name=re_assigned]').val(0);
            $('#assigned_to_id').val('');
        }
    }
    $(document).ready(function () {
        reassign();
  function SimpleUploadAdapter(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = function(loader) {
      return {
        upload: function() {
          return loader.file
            .then(function (file) {
              return new Promise(function(resolve, reject) {
                // Init request
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo e(route('admin.appointment-bookings.storeCKEditorImages')); ?>', true);
                xhr.setRequestHeader('x-csrf-token', window._token);
                xhr.setRequestHeader('Accept', 'application/json');
                xhr.responseType = 'json';

                // Init listeners
                var genericErrorText = `Couldn't upload file: ${ file.name }.`;
                xhr.addEventListener('error', function() { reject(genericErrorText) });
                xhr.addEventListener('abort', function() { reject() });
                xhr.addEventListener('load', function() {
                  var response = xhr.response;

                  if (!response || xhr.status !== 201) {
                    return reject(response && response.message ? `${genericErrorText}\n${xhr.status} ${response.message}` : `${genericErrorText}\n ${xhr.status} ${xhr.statusText}`);
                  }

                  $('form').append('<input type="hidden" name="ck-media[]" value="' + response.id + '">');

                  resolve({ default: response.url });
                });

                if (xhr.upload) {
                  xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                      loader.uploadTotal = e.total;
                      loader.uploaded = e.loaded;
                    }
                  });
                }

                // Send request
                var data = new FormData();
                data.append('upload', file);
                data.append('crud_id', '<?php echo e($appointmentBooking->id ?? 0); ?>');
                xhr.send(data);
              });
            })
        }
      };
    }
  }

  var allEditors = document.querySelectorAll('.ckeditor');
  for (var i = 0; i < allEditors.length; ++i) {
    ClassicEditor.create(
      allEditors[i], {
        extraPlugins: [SimpleUploadAdapter]
      }
    );
  }
});

function ApprovalCheck(arg){

    if(arg == 'approved'){
        document.getElementById('disapproved').checked=false;
        $('[name=approved]').val(1); re_assigned
        $('[name=in_progress]').val(1);
        $('[name=disapproved]').val(0);

    } else if(arg == 'disapproved'){
        document.getElementById('approved').checked  = false;
        $('[name=approved]').val(0);
        $('[name=in_progress]').val(0);
        $('[name=disapproved]').val(1);
    }

}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/appointmentBookings/edit.blade.php ENDPATH**/ ?>