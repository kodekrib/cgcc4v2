<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.department.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.departments.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="dept_code"><?php echo e(trans('cruds.department.fields.dept_code')); ?></label>
                <input class="form-control <?php echo e($errors->has('dept_code') ? 'is-invalid' : ''); ?>" type="text" name="dept_code" id="dept_code" value="<?php echo e(old('dept_code', '')); ?>" required>
                <?php if($errors->has('dept_code')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('dept_code')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.department.fields.dept_code_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="department_name"><?php echo e(trans('cruds.department.fields.department_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('department_name') ? 'is-invalid' : ''); ?>" type="text" name="department_name" id="department_name" value="<?php echo e(old('department_name', '')); ?>" required>
                <?php if($errors->has('department_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('department_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.department.fields.department_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="department_email"><?php echo e(trans('cruds.department.fields.department_email')); ?></label>
                <input class="form-control <?php echo e($errors->has('department_email') ? 'is-invalid' : ''); ?>" type="email" name="department_email" id="department_email" value="<?php echo e(old('department_email')); ?>" required>
                <?php if($errors->has('department_email')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('department_email')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.department.fields.department_email_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="hod_id"><?php echo e(trans('cruds.department.fields.hod')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('hod') ? 'is-invalid' : ''); ?>" name="hod_id" id="hod_id" required>
                    <?php $__currentLoopData = $hods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('hod_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('hod')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('hod')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.department.fields.hod_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="organization_type_id"><?php echo e(trans('cruds.department.fields.organization_type')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('organization_type') ? 'is-invalid' : ''); ?>" name="organization_type_id" id="organization_type_id" required>
                    <?php $__currentLoopData = $organization_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('organization_type_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('organization_type')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('organization_type')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.department.fields.organization_type_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/departments/create.blade.php ENDPATH**/ ?>