<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.typeOfAppoinment.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.type-of-appoinments.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.typeOfAppoinment.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($typeOfAppoinment->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.typeOfAppoinment.fields.type')); ?>

                        </th>
                        <td>
                            <?php echo e($typeOfAppoinment->type); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            Default Member
                        </th>
                        <td>
                            <?php echo e($typeOfAppoinment->default_members->member_name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            Default Member Email
                        </th>
                        <td>
                            <?php echo e($typeOfAppoinment->default_members->email); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            Member Managing Type
                        </th>
                        <td>
                                 <?php $__currentLoopData = $typeOfAppoinment->memberManageAppointmentType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge badge-info"><?php echo e($item->member_name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.type-of-appoinments.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/typeOfAppoinments/show.blade.php ENDPATH**/ ?>