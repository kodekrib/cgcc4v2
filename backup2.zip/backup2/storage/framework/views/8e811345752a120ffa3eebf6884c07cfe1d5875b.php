<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('meeting_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.meetings.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.meeting.title_singular')); ?>

            </a>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.meeting.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-Meeting">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.meeting.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.meeting.fields.meeting_type')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.meeting.fields.date_of_meeting')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.meeting.fields.time_duration')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.meeting.fields.meeting_title')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.meeting.fields.venue')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.meeting.fields.attendees')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.meeting.fields.meeting_minutes')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.meeting.fields.files')); ?>

                        </th>
                        <th>
                        Approval Status
                        </th>

                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $meetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $meeting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($meeting->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($meeting->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($meeting->meeting_type->types ?? ''); ?>

                            </td>
                            <td>
                                <a class="btn btn-xs btn-primary" href="#" onclick="loadDialog('<?php echo e($meeting->id); ?>')" >
                                        <?php echo e(trans('global.view')); ?>  Date List
                                </a>
                            </td>
                            <td>
                                <?php echo e($meeting->time_duration ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($meeting->meeting_title ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($meeting->venue->venue_name ?? ''); ?>

                            </td>
                            <td>
                                <a class="btn btn-xs btn-primary" href="#" onclick="GetMeetingAttendee('<?php echo e($meeting->id); ?>')" >
                                        <?php echo e(trans('global.view')); ?>  Attendee List
                                </a>
                            </td>
                            <td>
                                <?php $__currentLoopData = $meeting->meeting_minutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e($media->getUrl()); ?>" target="_blank">
                                        <?php echo e(trans('global.view_file')); ?>

                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php $__currentLoopData = $meeting->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e($media->getUrl()); ?>" target="_blank">
                                        <?php echo e(trans('global.view_file')); ?>

                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                            <?php if($meeting->approval_status == 0): ?>
                                            <a class="btn btn-xs btn-secondary" >
                                                Pending
                                            </a>
                                        <?php endif; ?>
                                        <?php if($meeting->approval_status == 1): ?>
                                            <a class="btn btn-xs btn-danger" style="color: white;">
                                                Disapproved
                                            </a>
                                        <?php endif; ?>
                                        <?php if($meeting->approval_status == 2): ?>
                                            <a class="btn btn-xs btn-success" style="color: white;">
                                            Approved
                                            </a>
                                        <?php endif; ?>
                            </td>
                            <!-- <td>
                                <span style="display:none"><?php echo e($meeting->approved ?? ''); ?></span>
                                <input type="checkbox" disabled="disabled" <?php echo e($meeting->approved ? 'checked' : ''); ?>>
                            </td>
                            <td>
                                <span style="display:none"><?php echo e($meeting->disapproved ?? ''); ?></span>
                                <input type="checkbox" disabled="disabled" <?php echo e($meeting->disapproved ? 'checked' : ''); ?>>
                            </td> -->
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('meeting_show')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.meetings.show', $meeting->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('meeting_edit')): ?>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.meetings.edit', $meeting->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('meeting_delete')): ?>
                                    <form action="<?php echo e(route('admin.meetings.destroy', $meeting->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                    </form>
                                <?php endif; ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="modal fade" id="dateListmodal" tabindex="-1" role="dialog" aria-labelledby="dateListModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="dateModal">Date list</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <div class="modal-body">
            <div class="table-responsive" style="width: 100% !important">
                    <table class="table table-bordered table-striped table-hover datatable" id="dateListTable">
                        <thead style="width: 100% !important;">
                            <tr>
                                <th>
                                    Sn
                                </th>
                                <th>
                                    Date(MM-DD-MMM)
                                </th>
                                <th>
                                    Day in a Week
                                </th>
                                <th>
                                    Time
                                </th>

                            </tr>
                        </thead>
                    </table>
            </div>
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <!-- <button type="button" class="btn btn-primary" onclick="onDelistAMember()">Delist Member</button> -->
        </div>
    </div>
  </div>
</div>


<!-- Modal -->
<div class="modal fade" id="addMoreModal" tabindex="-1" role="dialog" aria-labelledby="addMoreModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addMoreModal">Member list</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <div class="modal-body">
            <div class="table-responsive" style="width: 100% !important">
                    <table class="table table-bordered table-striped table-hover datatable" id="memberListTable">
                        <thead style="width: 100% !important;">
                            <tr>
                                <th>
                                    Member Name
                                </th>
                                <th>
                                    Email
                                </th>
                                <th>
                                    Phone Number
                                </th>

                            </tr>
                        </thead>
                    </table>
            </div>
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <!-- <button type="button" class="btn btn-primary" onclick="onDelistAMember()">Delist Member</button> -->
        </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>

    var dateListTable;
    var  tableList;
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('meeting_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.meetings.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 2, 'desc' ]],
    pageLength: 50,
  });
  let table = $('.datatable-Meeting:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });

  dateListTable =  $('#dateListTable').DataTable(
            {
                destroy: true,
                data: [],
                processing: true,
                buttons: [],
                pageLength: 10,
                responsive: true,
                columns: [
                    {
                            className: 'none',
                            data: null,
                            defaultContent: '',
                            targets: 0,
                            render: function (data, type, full, meta) {
                                return (meta.row+ 1);
                            }
                    },
                    {
                            className: 'none',
                            data: null,
                            defaultContent: '',
                            targets: 1,
                            render: function (data, type, full, meta) {

                                return `<span>${data.date}</span>`;
                            }
                    },
                    {
                            className: 'none',
                            data: null,
                            defaultContent: '',
                            render: function (data, type, full, meta) {
                                return `<span>${GetDayinWeek(data.date)}</span>`;
                            }
                    },
                    {
                            className: 'none',
                            data: null,
                            defaultContent: '',
                            render: function (data, type, full, meta) {
                                return `<span>${data.time}</span>`;
                            }
                    },
                ]

            });
            tableList =  $('#memberListTable').DataTable(
                            {
                                destroy: true,
                                processing: true,

                                data : [],
                                buttons: [

                                ],
                                processing: true,

                                columns: [

                                    {
                                        className: 'none',
                                        data: 'member_name',
                                        defaultContent: '',
                                        render: function (data, type, full, meta) {
                                            return data;
                                        }
                                    },

                                    { data: 'email', name: 'email' },
                                    { data: 'mobile', name: 'mobile' },
                                ],

                            });
})



</script>

<script>
    function GetMeetingAttendee(id){
        Get(`/admin/meetings/GetMeetingAttendee/${id}`,true).then(res => {
            tableList.clear().draw();
            tableList.rows.add(res).draw();
            $('#addMoreModal').modal('show');
            setTimeout(function(){
                tableList.columns.adjust()

            },300);
        })
    }
    function loadDialog(id){
        Get(`/admin/meetings/GetMeetingById/${id}`,true).then(res => {
            if(res == null) return;

            var dt = JSON.parse(res.date_of_meeting);
            $('#dateListmodal').modal('show');
            dateListTable.clear().draw();
            dateListTable.rows.add(dt).draw();

            setTimeout(function(){
                dateListTable.columns.adjust()

            },300);
        });

    }

    function GetDayinWeek(date){
        const weeks = [
            "Sunday",
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday"
        ];
        var dt  = new Date(date);
        return weeks[dt.getDay()];
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/meetings/index.blade.php ENDPATH**/ ?>