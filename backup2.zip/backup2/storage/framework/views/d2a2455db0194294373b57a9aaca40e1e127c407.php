<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.employmentDetail.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.employment-details.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.employmentDetail.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($employmentDetail->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.employmentDetail.fields.employer_name')); ?>

                        </th>
                        <td>
                            <?php echo e($employmentDetail->employer_name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.employmentDetail.fields.employer_address')); ?>

                        </th>
                        <td>
                            <?php echo e($employmentDetail->employer_address); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.employmentDetail.fields.employer_address_2')); ?>

                        </th>
                        <td>
                            <?php echo e($employmentDetail->employer_address_2); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.employmentDetail.fields.country')); ?>

                        </th>
                        <td>
                            <?php echo e($employmentDetail->country?? 'N/A'); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.employmentDetail.fields.state')); ?>

                        </th>
                        <td>
                            <?php echo e($employmentDetail->state ?? 'N/A'); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.employmentDetail.fields.city')); ?>

                        </th>
                        <td>
                            <?php echo e($employmentDetail->city); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.employmentDetail.fields.position_held')); ?>

                        </th>
                        <td>
                            <?php echo e($employmentDetail->position_held); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.employmentDetail.fields.industry')); ?>

                        </th>
                        <td>
                            <?php echo e($employmentDetail->industry->industry ?? 'N/A'); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.employmentDetail.fields.subsector')); ?>

                        </th>
                        <td>
                            <?php echo e($employmentDetail->subsector->name ?? 'N/A'); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.employment-details.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/employmentDetails/show.blade.php ENDPATH**/ ?>