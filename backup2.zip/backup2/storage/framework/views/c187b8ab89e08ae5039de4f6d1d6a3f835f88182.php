<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.joinDepartment.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.join-departments.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="department_id"><?php echo e(trans('cruds.joinDepartment.fields.department')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('department') ? 'is-invalid' : ''); ?>" name="department_id" id="department_id" required>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('department_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('department')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('department')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.joinDepartment.fields.department_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.joinDepartment.fields.primary_function')); ?></label>
                <select class="form-control <?php echo e($errors->has('primary_function') ? 'is-invalid' : ''); ?>" name="primary_function" id="primary_function">
                    <option value disabled <?php echo e(old('primary_function', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\JoinDepartment::PRIMARY_FUNCTION_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('primary_function', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('primary_function')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('primary_function')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.joinDepartment.fields.primary_function_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/joinDepartments/create.blade.php ENDPATH**/ ?>