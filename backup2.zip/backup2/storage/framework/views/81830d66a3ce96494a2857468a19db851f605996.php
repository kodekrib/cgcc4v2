<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.qualification.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.qualifications.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="highest_qualifications_id"><?php echo e(trans('cruds.qualification.fields.highest_qualifications')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('highest_qualifications') ? 'is-invalid' : ''); ?>" name="highest_qualifications_id" id="highest_qualifications_id" required>
                    <?php $__currentLoopData = $highest_qualifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('highest_qualifications_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('highest_qualifications')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('highest_qualifications')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.qualification.fields.highest_qualifications_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="professional_qualification"><?php echo e(trans('cruds.qualification.fields.professional_qualification')); ?></label>
                <input class="form-control <?php echo e($errors->has('professional_qualification') ? 'is-invalid' : ''); ?>" type="text" name="professional_qualification" id="professional_qualification" value="<?php echo e(old('professional_qualification', '')); ?>">
                <?php if($errors->has('professional_qualification')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('professional_qualification')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.qualification.fields.professional_qualification_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/qualifications/create.blade.php ENDPATH**/ ?>