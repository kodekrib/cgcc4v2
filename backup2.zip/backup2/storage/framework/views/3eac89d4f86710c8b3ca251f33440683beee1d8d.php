<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.joinDepartment.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.join-departments.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.joinDepartment.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($joinDepartment->id); ?>

                        </td>
                    </tr>


                    <tr>
                        <th>
                            <?php echo e(trans('cruds.joinDepartment.fields.member_name')); ?>

                        </th>
                        <td>
                            <?php echo e($joinDepartment->member->member_name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.joinDepartment.fields.member_Email')); ?>

                        </th>
                        <td>
                            <?php echo e($joinDepartment->member->email ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.joinDepartment.fields.member_phoneNumber')); ?>

                        </th>
                        <td>
                            <?php echo e($joinDepartment->member->mobile ?? ''); ?>

                        </td>
                    </tr>


                    <tr>
                        <th>
                            <?php echo e(trans('cruds.joinDepartment.fields.department')); ?>

                        </th>
                        <td>
                            <?php echo e($joinDepartment->department->department_name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.joinDepartment.fields.member_type')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\JoinDepartment::MEMBER_TYPE_SELECT[$joinDepartment->member_type] ?? 'N/A'); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.joinDepartment.fields.primary_function')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\JoinDepartment::PRIMARY_FUNCTION_SELECT[$joinDepartment->primary_function] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.joinDepartment.fields.approval_status')); ?>

                        </th>
                        <td>
                            <!-- <input type="checkbox" disabled="disabled" <?php echo e($joinDepartment->approval_status ? 'checked' : ''); ?>> -->
                            <?php if($joinDepartment->approval_status == 0): ?>
                                Pending
                            <?php elseif( $joinDepartment->approval_status == 1): ?>
                                Disapproved
                            <?php else: ?>
                                Approved
                            <?php endif; ?>

                        </td>
                    </tr>
                     <tr>
                        <th>
                            Status
                        </th>
                        <td>
                            <input type="checkbox" disabled="disabled" <?php echo e($joinDepartment->status ? 'checked' : ''); ?>>
                        </td>
                    </tr>
                   <!-- <tr>
                        <th>
                            <?php echo e(trans('cruds.joinDepartment.fields.disapproved')); ?>

                        </th>
                        <td>
                            <input type="checkbox" disabled="disabled" <?php echo e($joinDepartment->disapproved ? 'checked' : ''); ?>>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.joinDepartment.fields.delisted')); ?>

                        </th>
                        <td>
                            <input type="checkbox" disabled="disabled" <?php echo e($joinDepartment->delisted ? 'checked' : ''); ?>>
                        </td>
                    </tr> -->
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.joinDepartment.fields.reason')); ?>

                        </th>
                        <td>
                            <?php echo e($joinDepartment->reason??'N/A'); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.join-departments.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/joinDepartments/show.blade.php ENDPATH**/ ?>