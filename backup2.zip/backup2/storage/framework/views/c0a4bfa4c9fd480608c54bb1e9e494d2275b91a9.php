<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.empowermentTrainingNeed.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.empowerment-training-needs.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="training_needs"><?php echo e(trans('cruds.empowermentTrainingNeed.fields.training_needs')); ?></label>
                <input class="form-control <?php echo e($errors->has('training_needs') ? 'is-invalid' : ''); ?>" type="text" name="training_needs" id="training_needs" value="<?php echo e(old('training_needs', '')); ?>">
                <?php if($errors->has('training_needs')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('training_needs')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.empowermentTrainingNeed.fields.training_needs_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/empowermentTrainingNeeds/create.blade.php ENDPATH**/ ?>