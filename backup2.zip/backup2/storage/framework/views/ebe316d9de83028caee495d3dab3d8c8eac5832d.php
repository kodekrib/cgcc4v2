<?php echo e($slot); ?>

<?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>