<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.employmentDetail.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.employment-details.update", [$employmentDetail->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="employer_name"><?php echo e(trans('cruds.employmentDetail.fields.employer_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('employer_name') ? 'is-invalid' : ''); ?>" type="text" name="employer_name" id="employer_name" value="<?php echo e(old('employer_name', $employmentDetail->employer_name)); ?>" required>
                <?php if($errors->has('employer_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('employer_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.employmentDetail.fields.employer_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="employer_address"><?php echo e(trans('cruds.employmentDetail.fields.employer_address')); ?></label>
                <input class="form-control <?php echo e($errors->has('employer_address') ? 'is-invalid' : ''); ?>" type="text" name="employer_address" id="employer_address" value="<?php echo e(old('employer_address', $employmentDetail->employer_address)); ?>">
                <?php if($errors->has('employer_address')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('employer_address')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.employmentDetail.fields.employer_address_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="employer_address_2"><?php echo e(trans('cruds.employmentDetail.fields.employer_address_2')); ?></label>
                <input class="form-control <?php echo e($errors->has('employer_address_2') ? 'is-invalid' : ''); ?>" type="text" name="employer_address_2" id="employer_address_2" value="<?php echo e(old('employer_address_2', $employmentDetail->employer_address_2)); ?>">
                <?php if($errors->has('employer_address_2')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('employer_address_2')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.employmentDetail.fields.employer_address_2_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.employmentDetail.fields.country')); ?></label>
                <select class="form-control <?php echo e($errors->has('country') ? 'is-invalid' : ''); ?>" name="country" id="country"  onchange="changeCountry()">
                    <option value disabled <?php echo e(old('country', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($data['name']); ?>" <?php echo e(old('country', $employmentDetail->country) === (string)$data['name'] ? 'selected' : ''); ?>><?php echo e($data['name']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('country')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('country')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.employmentDetail.fields.country_helper')); ?></span>
            </div>
            <div class="form-group"  id="state_dropDown">
                <label><?php echo e(trans('cruds.employmentDetail.fields.state')); ?></label>
                <select class="form-control <?php echo e($errors->has('state') ? 'is-invalid' : ''); ?>" name="state" id="state">
                    <option value disabled <?php echo e(old('state', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($label['state']); ?>" <?php echo e(old('state', $employmentDetail->state) === (string) $label['state'] ? 'selected' : ''); ?>><?php echo e($label['state']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('state')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('state')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.employmentDetail.fields.state_helper')); ?></span>
            </div>
            <div class="form-group" id="state_text">
                <label><?php echo e(trans('cruds.employmentDetail.fields.state')); ?></label>
                <input class="form-control <?php echo e($errors->has('state') ? 'is-invalid' : ''); ?>" type="text" name="state" id="state_str"  value="<?php echo e(old('state', $employmentDetail->state)); ?>">
                <?php if($errors->has('state')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('state')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.employmentDetail.fields.state_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="city"><?php echo e(trans('cruds.employmentDetail.fields.city')); ?></label>
                <input class="form-control <?php echo e($errors->has('city') ? 'is-invalid' : ''); ?>" type="text" name="city" id="city" value="<?php echo e(old('city', $employmentDetail->city)); ?>">
                <?php if($errors->has('city')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('city')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.employmentDetail.fields.city_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="position_held"><?php echo e(trans('cruds.employmentDetail.fields.position_held')); ?></label>
                <input class="form-control <?php echo e($errors->has('position_held') ? 'is-invalid' : ''); ?>" type="text" name="position_held" id="position_held" value="<?php echo e(old('position_held', $employmentDetail->position_held)); ?>">
                <?php if($errors->has('position_held')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('position_held')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.employmentDetail.fields.position_held_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="industry_id"><?php echo e(trans('cruds.employmentDetail.fields.industry')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('industry') ? 'is-invalid' : ''); ?>" name="industry_id" id="industry_id">
                    <?php $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('industry_id') ? old('industry_id') : $employmentDetail->industry->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('industry')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('industry')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.employmentDetail.fields.industry_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="subsector_id"><?php echo e(trans('cruds.employmentDetail.fields.subsector')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('subsector') ? 'is-invalid' : ''); ?>" name="subsector_id" id="subsector_id">
                    <?php $__currentLoopData = $subsectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('subsector_id') ? old('subsector_id') : $employmentDetail->subsector->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('subsector')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('subsector')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.employmentDetail.fields.subsector_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
        function changeCountry(){
            const state_text = document.getElementById('state_text');
            const state_dropDown = document.getElementById('state_dropDown');
            const value = $('#country').val();
            if(value !== "Nigeria"){
                state_dropDown.style.display = "none";
                //lgaContainer.style.display = "none";
                state_text.style.display = "block"
                document.getElementById('state_str').disabled = false;
            } else {
                state_dropDown.style.display = "block";
                //lgaContainer.style.display = "block";
                state_text.style.display = "none"
                document.getElementById('state_str').disabled = true;
            }
        }
        $(document).ready(() => {
           // $('#country option[value="Nigeria"]').attr("selected",true);
            changeCountry();
        })
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/employmentDetails/edit.blade.php ENDPATH**/ ?>