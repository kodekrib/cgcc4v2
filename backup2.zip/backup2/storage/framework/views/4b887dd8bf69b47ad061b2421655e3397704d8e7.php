<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.member.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.members.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($member->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.image')); ?>

                        </th>
                        <td>
                            <?php if($member->image): ?>
                                <a href="<?php echo e($member->image->getUrl()); ?>" target="_blank" style="display: inline-block">
                                    <img src="<?php echo e($member->image->getUrl('thumb')); ?>">
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.title')); ?>

                        </th>
                        <td>
                            <?php echo e($member->title->title ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.member_name')); ?>

                        </th>
                        <td>
                            <?php echo e($member->member_name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.middlename')); ?>

                        </th>
                        <td>
                            <?php echo e($member->middlename); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.mobile')); ?>

                        </th>
                        <td>
                            <?php echo e($member->mobile); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.email')); ?>

                        </th>
                        <td>
                            <?php echo e($member->email); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.date_of_birth')); ?>

                        </th>
                        <td>
                            <?php echo e($member->date_of_birth); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.age')); ?>

                        </th>
                        <td>
                            <?php echo e($member->age); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.gender')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Member::GENDER_SELECT[$member->gender] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.marital_status')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Member::MARITAL_STATUS_SELECT[$member->marital_status] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.employment_status')); ?>

                        </th>
                        <td>
                            <?php echo e($member->employment_status->employment_status ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.born_in_nigeria')); ?>

                        </th>
                        <td>
                            <input type="checkbox" disabled="disabled" <?php echo e($member->born_in_nigeria ? 'checked' : ''); ?>>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.place_of_birth')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Member::PLACE_OF_BIRTH_SELECT[$member->place_of_birth] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.country_of_birth')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Member::COUNTRY_OF_BIRTH_SELECT[$member->country_of_birth] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.nationality')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Member::NATIONALITY_SELECT[$member->nationality] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.state_of_origin')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Member::STATE_OF_ORIGIN_SELECT[$member->state_of_origin] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.lga')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Member::LGA_SELECT[$member->lga] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.address_1')); ?>

                        </th>
                        <td>
                            <?php echo e($member->address_1); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.address_2')); ?>

                        </th>
                        <td>
                            <?php echo e($member->address_2); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.nearest_bus_stop')); ?>

                        </th>
                        <td>
                            <?php echo e($member->nearest_bus_stop); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.member.fields.affinity_group')); ?>

                        </th>
                        <td>
                            <?php echo e($member->affinity_group); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.members.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.relatedData')); ?>

    </div>
    <ul class="nav nav-tabs" role="tablist" id="relationship-tabs">
        <li class="nav-item">
            <a class="nav-link" href="#created_by_children" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.child.title')); ?>

            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#created_by_members_affinity_groups" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.membersAffinityGroup.title')); ?>

            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#father_name_children" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.child.title')); ?>

            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#mothers_name_children" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.child.title')); ?>

            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#members_in_attendance_attendance_managements" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.attendanceManagement.title')); ?>

            </a>
        </li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane" role="tabpanel" id="created_by_children">
            <?php if ($__env->exists('admin.members.relationships.createdByChildren', ['children' => $member->createdByChildren])) echo $__env->make('admin.members.relationships.createdByChildren', ['children' => $member->createdByChildren], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="tab-pane" role="tabpanel" id="created_by_members_affinity_groups">
            <?php if ($__env->exists('admin.members.relationships.createdByMembersAffinityGroups', ['membersAffinityGroups' => $member->createdByMembersAffinityGroups])) echo $__env->make('admin.members.relationships.createdByMembersAffinityGroups', ['membersAffinityGroups' => $member->createdByMembersAffinityGroups], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="tab-pane" role="tabpanel" id="father_name_children">
            <?php if ($__env->exists('admin.members.relationships.fatherNameChildren', ['children' => $member->fatherNameChildren])) echo $__env->make('admin.members.relationships.fatherNameChildren', ['children' => $member->fatherNameChildren], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="tab-pane" role="tabpanel" id="mothers_name_children">
            <?php if ($__env->exists('admin.members.relationships.mothersNameChildren', ['children' => $member->mothersNameChildren])) echo $__env->make('admin.members.relationships.mothersNameChildren', ['children' => $member->mothersNameChildren], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="tab-pane" role="tabpanel" id="members_in_attendance_attendance_managements">
            <?php if ($__env->exists('admin.members.relationships.membersInAttendanceAttendanceManagements', ['attendanceManagements' => $member->membersInAttendanceAttendanceManagements])) echo $__env->make('admin.members.relationships.membersInAttendanceAttendanceManagements', ['attendanceManagements' => $member->membersInAttendanceAttendanceManagements], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/members/show.blade.php ENDPATH**/ ?>