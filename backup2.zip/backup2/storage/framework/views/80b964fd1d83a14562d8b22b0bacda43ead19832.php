<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('first_timer_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.first-timers.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.firstTimer.title_singular')); ?>

            </a>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.firstTimer.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-FirstTimer">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.service')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.surname')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.first_name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.middle_name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.date_of_birth')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.marital_status')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.occupation')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.gender')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.age')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.phone_number')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.email')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.residential_address')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.nearest_bus_stop')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.country')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.state')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.city')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.join_cgcc')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.start_ats')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.ats_mode')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.firstTimer.fields.prayer_request')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $firstTimers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $firstTimer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($firstTimer->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($firstTimer->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($firstTimer->service ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($firstTimer->surname ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($firstTimer->first_name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($firstTimer->middle_name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($firstTimer->date_of_birth ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($firstTimer->marital_status->marital_status ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($firstTimer->occupation ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\FirstTimer::GENDER_SELECT[$firstTimer->gender] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($firstTimer->age ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($firstTimer->phone_number ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($firstTimer->email ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($firstTimer->residential_address ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($firstTimer->nearest_bus_stop ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\FirstTimer::COUNTRY_SELECT[$firstTimer->country] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\FirstTimer::STATE_SELECT[$firstTimer->state] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\FirstTimer::CITY_SELECT[$firstTimer->city] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\FirstTimer::JOIN_CGCC_SELECT[$firstTimer->join_cgcc] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\FirstTimer::START_ATS_SELECT[$firstTimer->start_ats] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\FirstTimer::ATS_MODE_SELECT[$firstTimer->ats_mode] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($firstTimer->prayer_request ?? ''); ?>

                            </td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('first_timer_show')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.first-timers.show', $firstTimer->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('first_timer_edit')): ?>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.first-timers.edit', $firstTimer->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('first_timer_delete')): ?>
                                    <form action="<?php echo e(route('admin.first-timers.destroy', $firstTimer->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                    </form>
                                <?php endif; ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('first_timer_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.first-timers.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 3, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-FirstTimer:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/firstTimers/index.blade.php ENDPATH**/ ?>