<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.appointmentBooking.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.appointment-bookings.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="member_name"><?php echo e(trans('cruds.appointmentBooking.fields.member_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('member_name') ? 'is-invalid' : ''); ?>" type="text" name="member_name" id="member_name" value="<?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->firstname); ?>" readonly required>
                <?php if($errors->has('member_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('member_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.appointmentBooking.fields.member_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="appointment_type_id"><?php echo e(trans('cruds.appointmentBooking.fields.appointment_type')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('appointment_type') ? 'is-invalid' : ''); ?>" name="appointment_type_id" id="appointment_type_id">
                    <?php $__currentLoopData = $appointment_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('appointment_type_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('appointment_type')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('appointment_type')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.appointmentBooking.fields.appointment_type_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="appointment_date"><?php echo e(trans('cruds.appointmentBooking.fields.appointment_date')); ?></label>
                <input class="form-control date <?php echo e($errors->has('appointment_date') ? 'is-invalid' : ''); ?>" type="text" name="appointment_date" id="appointment_date" value="<?php echo e(old('appointment_date')); ?>" required>
                <?php if($errors->has('appointment_date')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('appointment_date')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.appointmentBooking.fields.appointment_date_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="appointment_time"><?php echo e(trans('cruds.appointmentBooking.fields.appointment_time')); ?></label>
                <input class="form-control timepicker <?php echo e($errors->has('appointment_time') ? 'is-invalid' : ''); ?>" type="text" name="appointment_time" id="appointment_time" value="<?php echo e(old('appointment_time')); ?>" required>
                <?php if($errors->has('appointment_time')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('appointment_time')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.appointmentBooking.fields.appointment_time_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="purpose"><?php echo e(trans('cruds.appointmentBooking.fields.purpose')); ?></label>
                <textarea class="form-control ckeditor <?php echo e($errors->has('purpose') ? 'is-invalid' : ''); ?>" name="purpose" id="purpose"><?php echo old('purpose'); ?></textarea>
                <?php if($errors->has('purpose')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('purpose')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.appointmentBooking.fields.purpose_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
  function SimpleUploadAdapter(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = function(loader) {
      return {
        upload: function() {
          return loader.file
            .then(function (file) {
              return new Promise(function(resolve, reject) {
                // Init request
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo e(route('admin.appointment-bookings.storeCKEditorImages')); ?>', true);
                xhr.setRequestHeader('x-csrf-token', window._token);
                xhr.setRequestHeader('Accept', 'application/json');
                xhr.responseType = 'json';

                // Init listeners
                var genericErrorText = `Couldn't upload file: ${ file.name }.`;
                xhr.addEventListener('error', function() { reject(genericErrorText) });
                xhr.addEventListener('abort', function() { reject() });
                xhr.addEventListener('load', function() {
                  var response = xhr.response;

                  if (!response || xhr.status !== 201) {
                    return reject(response && response.message ? `${genericErrorText}\n${xhr.status} ${response.message}` : `${genericErrorText}\n ${xhr.status} ${xhr.statusText}`);
                  }

                  $('form').append('<input type="hidden" name="ck-media[]" value="' + response.id + '">');

                  resolve({ default: response.url });
                });

                if (xhr.upload) {
                  xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                      loader.uploadTotal = e.total;
                      loader.uploaded = e.loaded;
                    }
                  });
                }

                // Send request
                var data = new FormData();
                data.append('upload', file);
                data.append('crud_id', '<?php echo e($appointmentBooking->id ?? 0); ?>');
                xhr.send(data);
              });
            })
        }
      };
    }
  }

  var allEditors = document.querySelectorAll('.ckeditor');
  for (var i = 0; i < allEditors.length; ++i) {
    ClassicEditor.create(
      allEditors[i], {
        extraPlugins: [SimpleUploadAdapter]
      }
    );
  }
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/appointmentBookings/create.blade.php ENDPATH**/ ?>