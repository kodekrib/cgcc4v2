<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attendance_management_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.attendance-managements.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.attendanceManagement.title_singular')); ?>

            </a>
        </div>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.attendanceManagement.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-membersInAttendanceAttendanceManagements">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.attendanceManagement.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.attendanceManagement.fields.meeting_type')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.attendanceManagement.fields.meeting_title')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.meeting.fields.meeting_title')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.attendanceManagement.fields.date')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.attendanceManagement.fields.summary_report')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.attendanceManagement.fields.external_files')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.attendanceManagement.fields.members_in_attendance')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.attendanceManagement.fields.age_category')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.attendanceManagement.fields.gender_category')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.attendanceManagement.fields.state_of_the_flock')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.attendanceManagement.fields.cih_centre')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.attendanceManagement.fields.present')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.attendanceManagement.fields.absent')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.attendanceManagement.fields.excused')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $attendanceManagements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attendanceManagement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($attendanceManagement->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($attendanceManagement->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($attendanceManagement->meeting_type->types ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($attendanceManagement->meeting_title->meeting_title ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($attendanceManagement->meeting_title->meeting_title ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($attendanceManagement->date ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($attendanceManagement->summary_report ?? ''); ?>

                            </td>
                            <td>
                                <?php $__currentLoopData = $attendanceManagement->external_files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e($media->getUrl()); ?>" target="_blank">
                                        <?php echo e(trans('global.view_file')); ?>

                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php $__currentLoopData = $attendanceManagement->members_in_attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge badge-info"><?php echo e($item->member_name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php echo e(App\Models\AttendanceManagement::AGE_CATEGORY_SELECT[$attendanceManagement->age_category] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\AttendanceManagement::GENDER_CATEGORY_SELECT[$attendanceManagement->gender_category] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($attendanceManagement->state_of_the_flock ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($attendanceManagement->cih_centre->zone ?? ''); ?>

                            </td>
                            <td>
                                <span style="display:none"><?php echo e($attendanceManagement->present ?? ''); ?></span>
                                <input type="checkbox" disabled="disabled" <?php echo e($attendanceManagement->present ? 'checked' : ''); ?>>
                            </td>
                            <td>
                                <span style="display:none"><?php echo e($attendanceManagement->absent ?? ''); ?></span>
                                <input type="checkbox" disabled="disabled" <?php echo e($attendanceManagement->absent ? 'checked' : ''); ?>>
                            </td>
                            <td>
                                <span style="display:none"><?php echo e($attendanceManagement->excused ?? ''); ?></span>
                                <input type="checkbox" disabled="disabled" <?php echo e($attendanceManagement->excused ? 'checked' : ''); ?>>
                            </td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attendance_management_show')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.attendance-managements.show', $attendanceManagement->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attendance_management_edit')): ?>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.attendance-managements.edit', $attendanceManagement->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attendance_management_delete')): ?>
                                    <form action="<?php echo e(route('admin.attendance-managements.destroy', $attendanceManagement->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                    </form>
                                <?php endif; ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attendance_management_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.attendance-managements.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 5, 'desc' ]],
    pageLength: 50,
  });
  let table = $('.datatable-membersInAttendanceAttendanceManagements:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?><?php /**PATH /home/adurl/domains/cgcc4.adurl.com.ng/public_html/resources/views/admin/members/relationships/membersInAttendanceAttendanceManagements.blade.php ENDPATH**/ ?>